/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="dxm-base-common-zhu" />
export * from './public-api';

import { SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs';
export declare class ChangeFilter {
    private changes;
    constructor(changes: SimpleChanges);
    notFirstAndEmpty<T>(key: string): Observable<T>;
    notEmpty<T>(key: string): Observable<T>;
}

import { Subject } from "rxjs/internal/Subject";
import { isDef, isHasVal } from "./base";
import { debounceTime, takeUntil } from "rxjs/operators";
import { fromEvent } from "rxjs";
/*
*   实现弹窗拖动的类
*   因为这是全局实现拖拽事件，所以observeModalOpen函数就算多次调用也只会生效一次
* Created by 唐钦洪 2024-05-14 15:02:01
* Copyright by 深医信息技术（深圳）有限公司
*/
export class ModalDrag {
    // modal弹窗拖拽移动
    static observeModalDrag() {
        // 已经被调用过了，则下次如果有再调用，不给执行后面步骤了
        if (this.isStart) {
            throw new Error('该函数只允许调用一次，请不要重复调用');
        }
        this.isStart = true;
        const bodyObserver = new MutationObserver((mutations) => {
            for (const record of mutations) {
                const isAddNodeFlag = (record.type === 'childList' && record.addedNodes?.length > 0);
                if (!isAddNodeFlag) {
                    continue;
                }
                const overlayEl = document.querySelector('.cdk-overlay-container');
                if (!isDef(overlayEl)) {
                    continue;
                }
                // 弹窗的DOM容器创建出来了，则不用再进行监听了
                bodyObserver.disconnect();
                // 直接监听弹窗事件
                this.modalBindEventAndListen();
                break;
            }
        });
        // 只监听body节点下有没有新的子元素生成，其他的都不需要监听，所以都设置成false
        bodyObserver.observe(document.body, {
            subtree: false, childList: true, attributeOldValue: false,
            characterDataOldValue: false, attributes: false, characterData: false
        });
    }
    static modalBindEventAndListen() {
        const overlayEl = document.querySelector('.cdk-overlay-container');
        const debounceSub = new Subject();
        const overLayWrap = 'cdk-global-overlay-wrapper';
        const observer = new MutationObserver((mutations) => {
            mutations.forEach(record => {
                record.addedNodes.forEach(addedNode => {
                    const el = addedNode;
                    // 有这个class类，证明此时是打开了一个新的弹窗，那么需要添加新的Subject，方便后续移除事件用
                    if (el.classList.contains(overLayWrap)) {
                        const id = new Date().getTime() + '';
                        el.setAttribute('openId', id);
                        this.destroyMap.set(id, new Subject());
                        return;
                    }
                });
                record.removedNodes.forEach(node => {
                    const openId = node.getAttribute('openId');
                    // 有id，证明此时关闭并销毁了某个弹窗，那么这个弹窗的鼠标事件也要移除
                    if (isDef(openId)) {
                        this.destroyMap.get(openId).next();
                        this.destroyMap.delete(openId);
                        return;
                    }
                });
            });
            const modalElList = overlayEl.querySelectorAll(`.${overLayWrap}`);
            // modalElList为0，证明此时是关闭弹窗操作，无需再对弹窗做事件绑定操作
            if (!isDef(modalElList) || modalElList.length === 0) {
                return;
            }
            debounceSub.next();
        });
        // DOM修改会很频繁，需要做一个防抖，设置1s吧，如果时间设置太小，有可能导致弹窗内容还没显示出来，
        // 下面获取弹窗宽度时，有可能得到错误的宽度，导致计算left值出现变差，故时间设置久点，弹窗内容基本渲染出来，此时再得到的宽度就比较正确
        debounceSub.pipe(debounceTime(1000)).subscribe(() => {
            // 这是弹窗最外层的DOM元素，操作这个DOM的left和top，就能实现拖拽效果了
            // 要获取所有的弹窗，因为可能有多个，比如：弹窗里面还能再打开弹窗
            const modalElList = overlayEl.querySelectorAll(`.${overLayWrap}`);
            modalElList.forEach(modal => {
                const modalOpenId = modal.getAttribute('openId');
                const modalEl = modal.querySelector(`div[role='document'].ant-modal`);
                // 原来不是fix定位，现在手动设置弹窗为fix定位，这样拖拽时，就能计算出拖动的距离，并重新设置left和top值了
                if (modalEl.style.position !== 'fixed') {
                    modalEl.style.position = 'fixed';
                    // 原来弹窗有个下边距，好像没啥卵用，干掉它吧
                    modalEl.style.paddingBottom = '0px';
                    const pxWidth = modalEl.getBoundingClientRect().width;
                    // left值等于视窗宽度的一半 - 弹窗宽度的一半
                    modalEl.style.left = `${document.documentElement.clientWidth / 2 - pxWidth / 2}px`;
                }
                const headEl = modalEl.querySelector('.ant-modal-header');
                if (!isDef(headEl)) {
                    return;
                }
                // 设置弹窗标题DOM为拖拽图标样式
                headEl.style.cursor = 'move';
                // 弹窗标题DOM已经绑定事件了，不需要再绑定直接返回
                const bindEvent = headEl.getAttribute('bindEvent');
                if (isHasVal(bindEvent)) {
                    return;
                }
                headEl.setAttribute('bindEvent', 'true');
                // 开始给标题DOM绑定拖拽事件
                fromEvent(headEl, 'mousedown').pipe(takeUntil(this.destroyMap.get(modalOpenId))).subscribe(event => {
                    let lastMouseX = event.clientX;
                    let lastMouseY = event.clientY;
                    const sub = new Subject();
                    // move和up事件应该绑定在全屏遮罩层的DOM上
                    fromEvent(overlayEl, 'mousemove').pipe(takeUntil(sub)).subscribe((moveEvent) => {
                        const moveClientX = moveEvent.clientX;
                        const moveClientY = moveEvent.clientY;
                        const oriLeft = modalEl.getBoundingClientRect().left;
                        const oriTop = modalEl.getBoundingClientRect().top;
                        let left;
                        let top;
                        if (lastMouseX > moveClientX) {
                            left = oriLeft - Math.abs(lastMouseX - moveClientX);
                        }
                        else {
                            left = oriLeft + Math.abs(lastMouseX - moveClientX);
                        }
                        if (lastMouseY > moveClientY) {
                            top = oriTop - Math.abs(lastMouseY - moveClientY);
                        }
                        else {
                            top = oriTop + Math.abs(lastMouseY - moveClientY);
                        }
                        // left = (left < 0 ? 0 : left);
                        top = (top < 0 ? 0 : top);
                        modalEl.style.left = `${left}px`;
                        modalEl.style.top = `${top}px`;
                        lastMouseX = moveClientX;
                        lastMouseY = moveClientY;
                    });
                    fromEvent(overlayEl, 'mouseup').pipe(takeUntil(sub)).subscribe(() => {
                        // 鼠标抬起后，解绑move和up事件
                        sub.next();
                    });
                });
            });
        });
        // 对遮罩DOM做observe监听，为了提高性能，只需要监听它的子节点变化（增加或删除）就行了，子节点及子节点后代属性或者属性改变无需监听
        // 不需要记录属性和数据的前后变化，所以这attributeOldValue和characterDataOldValue都设置为false
        observer.observe(overlayEl, {
            subtree: false, childList: true, attributeOldValue: false,
            characterDataOldValue: false, attributes: false, characterData: false
        });
        // 首次打开弹窗，同样也要执行下面的操作
        const modalWrap = overlayEl.querySelector(`.${overLayWrap}`);
        const idWrap = new Date().getTime() + '';
        modalWrap.setAttribute('openId', idWrap);
        this.destroyMap.set(idWrap, new Subject());
        // 因为此时“div .cdk-overlay-container”的DOM已经创建完弹窗了，上面监听overlayEl不会触发，所以需要手动触发监听一次
        debounceSub.next();
    }
}
// 用来存储当前所有已打开弹窗的Map，主要用来实现弹窗销毁时取消该弹窗的鼠标事件
// key是id，value是事件监听的subject
ModalDrag.destroyMap = new Map();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kYWwtZHJhZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL2R4bS1iYXNlLWNvbW1vbi16aHUvc3JjL2NvbW1vbi91dGlscy9tb2RhbC1kcmFnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBQyxPQUFPLEVBQUMsTUFBTSx1QkFBdUIsQ0FBQztBQUM5QyxPQUFPLEVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBQyxNQUFNLFFBQVEsQ0FBQztBQUN2QyxPQUFPLEVBQUMsWUFBWSxFQUFFLFNBQVMsRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQ3ZELE9BQU8sRUFBQyxTQUFTLEVBQUMsTUFBTSxNQUFNLENBQUM7QUFFL0I7Ozs7O0VBS0U7QUFDRixNQUFNLE9BQU8sU0FBUztJQU9wQixjQUFjO0lBQ2QsTUFBTSxDQUFDLGdCQUFnQjtRQUNyQiw4QkFBOEI7UUFDOUIsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ2hCLE1BQU0sSUFBSSxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQztTQUN2QztRQUNELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3BCLE1BQU0sWUFBWSxHQUFHLElBQUksZ0JBQWdCLENBQUMsQ0FBQyxTQUEyQixFQUFFLEVBQUU7WUFDeEUsS0FBSyxNQUFNLE1BQU0sSUFBSSxTQUFTLEVBQUU7Z0JBQzlCLE1BQU0sYUFBYSxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksS0FBSyxXQUFXLElBQUksTUFBTSxDQUFDLFVBQVUsRUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3JGLElBQUksQ0FBQyxhQUFhLEVBQUU7b0JBQ2xCLFNBQVM7aUJBQ1Y7Z0JBQ0QsTUFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBaUIsd0JBQXdCLENBQUMsQ0FBQztnQkFDbkYsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDckIsU0FBUztpQkFDVjtnQkFDRCwwQkFBMEI7Z0JBQzFCLFlBQVksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDMUIsV0FBVztnQkFDWCxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztnQkFDL0IsTUFBTTthQUNQO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDSCw2Q0FBNkM7UUFDN0MsWUFBWSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO1lBQ2xDLE9BQU8sRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxLQUFLO1lBQ3pELHFCQUFxQixFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLGFBQWEsRUFBRSxLQUFLO1NBQ3RFLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTyxNQUFNLENBQUMsdUJBQXVCO1FBQ3BDLE1BQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQWlCLHdCQUF3QixDQUFDLENBQUM7UUFDbkYsTUFBTSxXQUFXLEdBQUcsSUFBSSxPQUFPLEVBQVEsQ0FBQztRQUN4QyxNQUFNLFdBQVcsR0FBRyw0QkFBNEIsQ0FBQztRQUNqRCxNQUFNLFFBQVEsR0FBRyxJQUFJLGdCQUFnQixDQUFDLENBQUMsU0FBMkIsRUFBRSxFQUFFO1lBQ3BFLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7Z0JBQ3pCLE1BQU0sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFO29CQUNwQyxNQUFNLEVBQUUsR0FBSSxTQUE0QixDQUFDO29CQUN6QyxxREFBcUQ7b0JBQ3JELElBQUksRUFBRSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEVBQUU7d0JBQ3RDLE1BQU0sRUFBRSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDO3dCQUNyQyxFQUFFLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUMsQ0FBQzt3QkFDOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxFQUFRLENBQUMsQ0FBQzt3QkFDN0MsT0FBTztxQkFDUjtnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFDSCxNQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDakMsTUFBTSxNQUFNLEdBQUksSUFBdUIsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7b0JBQy9ELHFDQUFxQztvQkFDckMsSUFBSSxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQ2pCLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO3dCQUNuQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDL0IsT0FBTztxQkFDUjtnQkFDSCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1lBQ0gsTUFBTSxXQUFXLEdBQUcsU0FBUyxDQUFDLGdCQUFnQixDQUFpQixJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7WUFDbEYsMENBQTBDO1lBQzFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksV0FBVyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ25ELE9BQU87YUFDUjtZQUNELFdBQVcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNyQixDQUFDLENBQUMsQ0FBQztRQUNILG9EQUFvRDtRQUNwRCxzRUFBc0U7UUFDdEUsV0FBVyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2xELDJDQUEyQztZQUMzQyxrQ0FBa0M7WUFDbEMsTUFBTSxXQUFXLEdBQUcsU0FBUyxDQUFDLGdCQUFnQixDQUFpQixJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7WUFDbEYsV0FBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDMUIsTUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztnQkFDakQsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBaUIsZ0NBQWdDLENBQUMsQ0FBQztnQkFDdEYsNERBQTREO2dCQUM1RCxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRTtvQkFDdEMsT0FBTyxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDO29CQUNqQyx3QkFBd0I7b0JBQ3hCLE9BQU8sQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLEtBQUssQ0FBQztvQkFDcEMsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO29CQUN0RCwyQkFBMkI7b0JBQzNCLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxHQUFHLE9BQU8sR0FBRyxDQUFDLElBQUksQ0FBQztpQkFDcEY7Z0JBQ0QsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBaUIsbUJBQW1CLENBQUMsQ0FBQztnQkFDMUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRTtvQkFDbEIsT0FBTztpQkFDUjtnQkFDRCxtQkFBbUI7Z0JBQ25CLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztnQkFDN0IsNEJBQTRCO2dCQUM1QixNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2dCQUNuRCxJQUFJLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDdkIsT0FBTztpQkFDUjtnQkFDRCxNQUFNLENBQUMsWUFBWSxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDekMsaUJBQWlCO2dCQUNqQixTQUFTLENBQWEsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRTtvQkFDN0csSUFBSSxVQUFVLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztvQkFDL0IsSUFBSSxVQUFVLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztvQkFDL0IsTUFBTSxHQUFHLEdBQWtCLElBQUksT0FBTyxFQUFRLENBQUM7b0JBQy9DLDJCQUEyQjtvQkFDM0IsU0FBUyxDQUFhLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxFQUFFLEVBQUU7d0JBQ3pGLE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUM7d0JBQ3RDLE1BQU0sV0FBVyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUM7d0JBQ3RDLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksQ0FBQzt3QkFDckQsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixFQUFFLENBQUMsR0FBRyxDQUFDO3dCQUNuRCxJQUFJLElBQUksQ0FBQzt3QkFDVCxJQUFJLEdBQUcsQ0FBQzt3QkFDUixJQUFJLFVBQVUsR0FBRyxXQUFXLEVBQUU7NEJBQzVCLElBQUksR0FBRyxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDLENBQUM7eUJBQ3JEOzZCQUFNOzRCQUNMLElBQUksR0FBRyxPQUFPLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDLENBQUM7eUJBQ3JEO3dCQUNELElBQUksVUFBVSxHQUFHLFdBQVcsRUFBRTs0QkFDNUIsR0FBRyxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUMsQ0FBQzt5QkFDbkQ7NkJBQU07NEJBQ0wsR0FBRyxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxXQUFXLENBQUMsQ0FBQzt5QkFDbkQ7d0JBQ0QsZ0NBQWdDO3dCQUNoQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO3dCQUMxQixPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxHQUFHLElBQUksSUFBSSxDQUFDO3dCQUNqQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO3dCQUUvQixVQUFVLEdBQUcsV0FBVyxDQUFDO3dCQUN6QixVQUFVLEdBQUcsV0FBVyxDQUFDO29CQUMzQixDQUFDLENBQUMsQ0FBQztvQkFDSCxTQUFTLENBQWEsU0FBUyxFQUFFLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO3dCQUM5RSxvQkFBb0I7d0JBQ3BCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQztvQkFDYixDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDSCx1RUFBdUU7UUFDdkUsc0VBQXNFO1FBQ3RFLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFO1lBQzFCLE9BQU8sRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxpQkFBaUIsRUFBRSxLQUFLO1lBQ3pELHFCQUFxQixFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLGFBQWEsRUFBRSxLQUFLO1NBQ3RFLENBQUMsQ0FBQztRQUNILHFCQUFxQjtRQUNyQixNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsYUFBYSxDQUFpQixJQUFJLFdBQVcsRUFBRSxDQUFDLENBQUM7UUFDN0UsTUFBTSxNQUFNLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFLENBQUM7UUFDekMsU0FBUyxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLElBQUksT0FBTyxFQUFRLENBQUMsQ0FBQztRQUNqRCw4RUFBOEU7UUFDOUUsV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3JCLENBQUM7O0FBdEpELDBDQUEwQztBQUMxQyw0QkFBNEI7QUFDckIsb0JBQVUsR0FBK0IsSUFBSSxHQUFHLEVBQXlCLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1N1YmplY3R9IGZyb20gXCJyeGpzL2ludGVybmFsL1N1YmplY3RcIjtcclxuaW1wb3J0IHtpc0RlZiwgaXNIYXNWYWx9IGZyb20gXCIuL2Jhc2VcIjtcclxuaW1wb3J0IHtkZWJvdW5jZVRpbWUsIHRha2VVbnRpbH0gZnJvbSBcInJ4anMvb3BlcmF0b3JzXCI7XHJcbmltcG9ydCB7ZnJvbUV2ZW50fSBmcm9tIFwicnhqc1wiO1xyXG5cclxuLypcclxuKiAgIOWunueOsOW8ueeql+aLluWKqOeahOexu1xyXG4qICAg5Zug5Li66L+Z5piv5YWo5bGA5a6e546w5ouW5ou95LqL5Lu277yM5omA5Lulb2JzZXJ2ZU1vZGFsT3BlbuWHveaVsOWwseeul+Wkmuasoeiwg+eUqOS5n+WPquS8mueUn+aViOS4gOasoVxyXG4qIENyZWF0ZWQgYnkg5ZSQ6ZKm5rSqIDIwMjQtMDUtMTQgMTU6MDI6MDFcclxuKiBDb3B5cmlnaHQgYnkg5rex5Yy75L+h5oGv5oqA5pyv77yI5rex5Zyz77yJ5pyJ6ZmQ5YWs5Y+4XHJcbiovXHJcbmV4cG9ydCBjbGFzcyBNb2RhbERyYWcge1xyXG5cclxuICAvLyDnlKjmnaXlrZjlgqjlvZPliY3miYDmnInlt7LmiZPlvIDlvLnnqpfnmoRNYXDvvIzkuLvopoHnlKjmnaXlrp7njrDlvLnnqpfplIDmr4Hml7blj5bmtojor6XlvLnnqpfnmoTpvKDmoIfkuovku7ZcclxuICAvLyBrZXnmmK9pZO+8jHZhbHVl5piv5LqL5Lu255uR5ZCs55qEc3ViamVjdFxyXG4gIHN0YXRpYyBkZXN0cm95TWFwOiBNYXA8c3RyaW5nLCBTdWJqZWN0PHZvaWQ+PiA9IG5ldyBNYXA8c3RyaW5nLCBTdWJqZWN0PHZvaWQ+PigpO1xyXG4gIHN0YXRpYyBpc1N0YXJ0OiBib29sZWFuO1xyXG5cclxuICAvLyBtb2RhbOW8ueeql+aLluaLveenu+WKqFxyXG4gIHN0YXRpYyBvYnNlcnZlTW9kYWxEcmFnKCkge1xyXG4gICAgLy8g5bey57uP6KKr6LCD55So6L+H5LqG77yM5YiZ5LiL5qyh5aaC5p6c5pyJ5YaN6LCD55So77yM5LiN57uZ5omn6KGM5ZCO6Z2i5q2l6aqk5LqGXHJcbiAgICBpZiAodGhpcy5pc1N0YXJ0KSB7XHJcbiAgICAgIHRocm93IG5ldyBFcnJvcign6K+l5Ye95pWw5Y+q5YWB6K646LCD55So5LiA5qyh77yM6K+35LiN6KaB6YeN5aSN6LCD55SoJyk7XHJcbiAgICB9XHJcbiAgICB0aGlzLmlzU3RhcnQgPSB0cnVlO1xyXG4gICAgY29uc3QgYm9keU9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKG11dGF0aW9uczogTXV0YXRpb25SZWNvcmRbXSkgPT4ge1xyXG4gICAgICBmb3IgKGNvbnN0IHJlY29yZCBvZiBtdXRhdGlvbnMpIHtcclxuICAgICAgICBjb25zdCBpc0FkZE5vZGVGbGFnID0gKHJlY29yZC50eXBlID09PSAnY2hpbGRMaXN0JyAmJiByZWNvcmQuYWRkZWROb2Rlcz8ubGVuZ3RoID4gMCk7XHJcbiAgICAgICAgaWYgKCFpc0FkZE5vZGVGbGFnKSB7XHJcbiAgICAgICAgICBjb250aW51ZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3Qgb3ZlcmxheUVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcjxIVE1MRGl2RWxlbWVudD4oJy5jZGstb3ZlcmxheS1jb250YWluZXInKTtcclxuICAgICAgICBpZiAoIWlzRGVmKG92ZXJsYXlFbCkpIHtcclxuICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgIH1cclxuICAgICAgICAvLyDlvLnnqpfnmoRET03lrrnlmajliJvlu7rlh7rmnaXkuobvvIzliJnkuI3nlKjlho3ov5vooYznm5HlkKzkuoZcclxuICAgICAgICBib2R5T2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xyXG4gICAgICAgIC8vIOebtOaOpeebkeWQrOW8ueeql+S6i+S7tlxyXG4gICAgICAgIHRoaXMubW9kYWxCaW5kRXZlbnRBbmRMaXN0ZW4oKTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgICAvLyDlj6rnm5HlkKxib2R56IqC54K55LiL5pyJ5rKh5pyJ5paw55qE5a2Q5YWD57Sg55Sf5oiQ77yM5YW25LuW55qE6YO95LiN6ZyA6KaB55uR5ZCs77yM5omA5Lul6YO96K6+572u5oiQZmFsc2VcclxuICAgIGJvZHlPYnNlcnZlci5vYnNlcnZlKGRvY3VtZW50LmJvZHksIHtcclxuICAgICAgc3VidHJlZTogZmFsc2UsIGNoaWxkTGlzdDogdHJ1ZSwgYXR0cmlidXRlT2xkVmFsdWU6IGZhbHNlLFxyXG4gICAgICBjaGFyYWN0ZXJEYXRhT2xkVmFsdWU6IGZhbHNlLCBhdHRyaWJ1dGVzOiBmYWxzZSwgY2hhcmFjdGVyRGF0YTogZmFsc2VcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBzdGF0aWMgbW9kYWxCaW5kRXZlbnRBbmRMaXN0ZW4oKSB7XHJcbiAgICBjb25zdCBvdmVybGF5RWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yPEhUTUxEaXZFbGVtZW50PignLmNkay1vdmVybGF5LWNvbnRhaW5lcicpO1xyXG4gICAgY29uc3QgZGVib3VuY2VTdWIgPSBuZXcgU3ViamVjdDx2b2lkPigpO1xyXG4gICAgY29uc3Qgb3ZlckxheVdyYXAgPSAnY2RrLWdsb2JhbC1vdmVybGF5LXdyYXBwZXInO1xyXG4gICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcigobXV0YXRpb25zOiBNdXRhdGlvblJlY29yZFtdKSA9PiB7XHJcbiAgICAgIG11dGF0aW9ucy5mb3JFYWNoKHJlY29yZCA9PiB7XHJcbiAgICAgICAgcmVjb3JkLmFkZGVkTm9kZXMuZm9yRWFjaChhZGRlZE5vZGUgPT4ge1xyXG4gICAgICAgICAgY29uc3QgZWwgPSAoYWRkZWROb2RlIGFzIEhUTUxEaXZFbGVtZW50KTtcclxuICAgICAgICAgIC8vIOaciei/meS4qmNsYXNz57G777yM6K+B5piO5q2k5pe25piv5omT5byA5LqG5LiA5Liq5paw55qE5by556qX77yM6YKj5LmI6ZyA6KaB5re75Yqg5paw55qEU3ViamVjdO+8jOaWueS+v+WQjue7reenu+mZpOS6i+S7tueUqFxyXG4gICAgICAgICAgaWYgKGVsLmNsYXNzTGlzdC5jb250YWlucyhvdmVyTGF5V3JhcCkpIHtcclxuICAgICAgICAgICAgY29uc3QgaWQgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKSArICcnO1xyXG4gICAgICAgICAgICBlbC5zZXRBdHRyaWJ1dGUoJ29wZW5JZCcsIGlkKTtcclxuICAgICAgICAgICAgdGhpcy5kZXN0cm95TWFwLnNldChpZCwgbmV3IFN1YmplY3Q8dm9pZD4oKSk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgICByZWNvcmQucmVtb3ZlZE5vZGVzLmZvckVhY2gobm9kZSA9PiB7XHJcbiAgICAgICAgICBjb25zdCBvcGVuSWQgPSAobm9kZSBhcyBIVE1MRGl2RWxlbWVudCkuZ2V0QXR0cmlidXRlKCdvcGVuSWQnKTtcclxuICAgICAgICAgIC8vIOaciWlk77yM6K+B5piO5q2k5pe25YWz6Zet5bm26ZSA5q+B5LqG5p+Q5Liq5by556qX77yM6YKj5LmI6L+Z5Liq5by556qX55qE6byg5qCH5LqL5Lu25Lmf6KaB56e76ZmkXHJcbiAgICAgICAgICBpZiAoaXNEZWYob3BlbklkKSkge1xyXG4gICAgICAgICAgICB0aGlzLmRlc3Ryb3lNYXAuZ2V0KG9wZW5JZCkubmV4dCgpO1xyXG4gICAgICAgICAgICB0aGlzLmRlc3Ryb3lNYXAuZGVsZXRlKG9wZW5JZCk7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICAgIGNvbnN0IG1vZGFsRWxMaXN0ID0gb3ZlcmxheUVsLnF1ZXJ5U2VsZWN0b3JBbGw8SFRNTERpdkVsZW1lbnQ+KGAuJHtvdmVyTGF5V3JhcH1gKTtcclxuICAgICAgLy8gbW9kYWxFbExpc3TkuLow77yM6K+B5piO5q2k5pe25piv5YWz6Zet5by556qX5pON5L2c77yM5peg6ZyA5YaN5a+55by556qX5YGa5LqL5Lu257uR5a6a5pON5L2cXHJcbiAgICAgIGlmICghaXNEZWYobW9kYWxFbExpc3QpIHx8IG1vZGFsRWxMaXN0Lmxlbmd0aCA9PT0gMCkge1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG4gICAgICBkZWJvdW5jZVN1Yi5uZXh0KCk7XHJcbiAgICB9KTtcclxuICAgIC8vIERPTeS/ruaUueS8muW+iOmikee5ge+8jOmcgOimgeWBmuS4gOS4qumYsuaKlu+8jOiuvue9rjFz5ZCn77yM5aaC5p6c5pe26Ze06K6+572u5aSq5bCP77yM5pyJ5Y+v6IO95a+86Ie05by556qX5YaF5a656L+Y5rKh5pi+56S65Ye65p2l77yMXHJcbiAgICAvLyDkuIvpnaLojrflj5blvLnnqpflrr3luqbml7bvvIzmnInlj6/og73lvpfliLDplJnor6/nmoTlrr3luqbvvIzlr7zoh7TorqHnrpdsZWZ05YC85Ye6546w5Y+Y5beu77yM5pWF5pe26Ze06K6+572u5LmF54K577yM5by556qX5YaF5a655Z+65pys5riy5p+T5Ye65p2l77yM5q2k5pe25YaN5b6X5Yiw55qE5a695bqm5bCx5q+U6L6D5q2j56GuXHJcbiAgICBkZWJvdW5jZVN1Yi5waXBlKGRlYm91bmNlVGltZSgxMDAwKSkuc3Vic2NyaWJlKCgpID0+IHtcclxuICAgICAgLy8g6L+Z5piv5by556qX5pyA5aSW5bGC55qERE9N5YWD57Sg77yM5pON5L2c6L+Z5LiqRE9N55qEbGVmdOWSjHRvcO+8jOWwseiDveWunueOsOaLluaLveaViOaenOS6hlxyXG4gICAgICAvLyDopoHojrflj5bmiYDmnInnmoTlvLnnqpfvvIzlm6DkuLrlj6/og73mnInlpJrkuKrvvIzmr5TlpoLvvJrlvLnnqpfph4zpnaLov5jog73lho3miZPlvIDlvLnnqpdcclxuICAgICAgY29uc3QgbW9kYWxFbExpc3QgPSBvdmVybGF5RWwucXVlcnlTZWxlY3RvckFsbDxIVE1MRGl2RWxlbWVudD4oYC4ke292ZXJMYXlXcmFwfWApO1xyXG4gICAgICBtb2RhbEVsTGlzdC5mb3JFYWNoKG1vZGFsID0+IHtcclxuICAgICAgICBjb25zdCBtb2RhbE9wZW5JZCA9IG1vZGFsLmdldEF0dHJpYnV0ZSgnb3BlbklkJyk7XHJcbiAgICAgICAgY29uc3QgbW9kYWxFbCA9IG1vZGFsLnF1ZXJ5U2VsZWN0b3I8SFRNTERpdkVsZW1lbnQ+KGBkaXZbcm9sZT0nZG9jdW1lbnQnXS5hbnQtbW9kYWxgKTtcclxuICAgICAgICAvLyDljp/mnaXkuI3mmK9maXjlrprkvY3vvIznjrDlnKjmiYvliqjorr7nva7lvLnnqpfkuLpmaXjlrprkvY3vvIzov5nmoLfmi5bmi73ml7bvvIzlsLHog73orqHnrpflh7rmi5bliqjnmoTot53nprvvvIzlubbph43mlrDorr7nva5sZWZ05ZKMdG9w5YC85LqGXHJcbiAgICAgICAgaWYgKG1vZGFsRWwuc3R5bGUucG9zaXRpb24gIT09ICdmaXhlZCcpIHtcclxuICAgICAgICAgIG1vZGFsRWwuc3R5bGUucG9zaXRpb24gPSAnZml4ZWQnO1xyXG4gICAgICAgICAgLy8g5Y6f5p2l5by556qX5pyJ5Liq5LiL6L656Led77yM5aW95YOP5rKh5ZWl5Y2155So77yM5bmy5o6J5a6D5ZCnXHJcbiAgICAgICAgICBtb2RhbEVsLnN0eWxlLnBhZGRpbmdCb3R0b20gPSAnMHB4JztcclxuICAgICAgICAgIGNvbnN0IHB4V2lkdGggPSBtb2RhbEVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xyXG4gICAgICAgICAgLy8gbGVmdOWAvOetieS6juinhueql+WuveW6pueahOS4gOWNiiAtIOW8ueeql+WuveW6pueahOS4gOWNilxyXG4gICAgICAgICAgbW9kYWxFbC5zdHlsZS5sZWZ0ID0gYCR7ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsaWVudFdpZHRoIC8gMiAtIHB4V2lkdGggLyAyfXB4YDtcclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgaGVhZEVsID0gbW9kYWxFbC5xdWVyeVNlbGVjdG9yPEhUTUxEaXZFbGVtZW50PignLmFudC1tb2RhbC1oZWFkZXInKTtcclxuICAgICAgICBpZiAoIWlzRGVmKGhlYWRFbCkpIHtcclxuICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLy8g6K6+572u5by556qX5qCH6aKYRE9N5Li65ouW5ou95Zu+5qCH5qC35byPXHJcbiAgICAgICAgaGVhZEVsLnN0eWxlLmN1cnNvciA9ICdtb3ZlJztcclxuICAgICAgICAvLyDlvLnnqpfmoIfpophET03lt7Lnu4/nu5Hlrprkuovku7bkuobvvIzkuI3pnIDopoHlho3nu5Hlrprnm7TmjqXov5Tlm55cclxuICAgICAgICBjb25zdCBiaW5kRXZlbnQgPSBoZWFkRWwuZ2V0QXR0cmlidXRlKCdiaW5kRXZlbnQnKTtcclxuICAgICAgICBpZiAoaXNIYXNWYWwoYmluZEV2ZW50KSkge1xyXG4gICAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuICAgICAgICBoZWFkRWwuc2V0QXR0cmlidXRlKCdiaW5kRXZlbnQnLCAndHJ1ZScpO1xyXG4gICAgICAgIC8vIOW8gOWni+e7meagh+mimERPTee7keWumuaLluaLveS6i+S7tlxyXG4gICAgICAgIGZyb21FdmVudDxNb3VzZUV2ZW50PihoZWFkRWwsICdtb3VzZWRvd24nKS5waXBlKHRha2VVbnRpbCh0aGlzLmRlc3Ryb3lNYXAuZ2V0KG1vZGFsT3BlbklkKSkpLnN1YnNjcmliZShldmVudCA9PiB7XHJcbiAgICAgICAgICBsZXQgbGFzdE1vdXNlWCA9IGV2ZW50LmNsaWVudFg7XHJcbiAgICAgICAgICBsZXQgbGFzdE1vdXNlWSA9IGV2ZW50LmNsaWVudFk7XHJcbiAgICAgICAgICBjb25zdCBzdWI6IFN1YmplY3Q8dm9pZD4gPSBuZXcgU3ViamVjdDx2b2lkPigpO1xyXG4gICAgICAgICAgLy8gbW92ZeWSjHVw5LqL5Lu25bqU6K+l57uR5a6a5Zyo5YWo5bGP6YGu572p5bGC55qERE9N5LiKXHJcbiAgICAgICAgICBmcm9tRXZlbnQ8TW91c2VFdmVudD4ob3ZlcmxheUVsLCAnbW91c2Vtb3ZlJykucGlwZSh0YWtlVW50aWwoc3ViKSkuc3Vic2NyaWJlKChtb3ZlRXZlbnQpID0+IHtcclxuICAgICAgICAgICAgY29uc3QgbW92ZUNsaWVudFggPSBtb3ZlRXZlbnQuY2xpZW50WDtcclxuICAgICAgICAgICAgY29uc3QgbW92ZUNsaWVudFkgPSBtb3ZlRXZlbnQuY2xpZW50WTtcclxuICAgICAgICAgICAgY29uc3Qgb3JpTGVmdCA9IG1vZGFsRWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkubGVmdDtcclxuICAgICAgICAgICAgY29uc3Qgb3JpVG9wID0gbW9kYWxFbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS50b3A7XHJcbiAgICAgICAgICAgIGxldCBsZWZ0O1xyXG4gICAgICAgICAgICBsZXQgdG9wO1xyXG4gICAgICAgICAgICBpZiAobGFzdE1vdXNlWCA+IG1vdmVDbGllbnRYKSB7XHJcbiAgICAgICAgICAgICAgbGVmdCA9IG9yaUxlZnQgLSBNYXRoLmFicyhsYXN0TW91c2VYIC0gbW92ZUNsaWVudFgpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIGxlZnQgPSBvcmlMZWZ0ICsgTWF0aC5hYnMobGFzdE1vdXNlWCAtIG1vdmVDbGllbnRYKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAobGFzdE1vdXNlWSA+IG1vdmVDbGllbnRZKSB7XHJcbiAgICAgICAgICAgICAgdG9wID0gb3JpVG9wIC0gTWF0aC5hYnMobGFzdE1vdXNlWSAtIG1vdmVDbGllbnRZKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICB0b3AgPSBvcmlUb3AgKyBNYXRoLmFicyhsYXN0TW91c2VZIC0gbW92ZUNsaWVudFkpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC8vIGxlZnQgPSAobGVmdCA8IDAgPyAwIDogbGVmdCk7XHJcbiAgICAgICAgICAgIHRvcCA9ICh0b3AgPCAwID8gMCA6IHRvcCk7XHJcbiAgICAgICAgICAgIG1vZGFsRWwuc3R5bGUubGVmdCA9IGAke2xlZnR9cHhgO1xyXG4gICAgICAgICAgICBtb2RhbEVsLnN0eWxlLnRvcCA9IGAke3RvcH1weGA7XHJcblxyXG4gICAgICAgICAgICBsYXN0TW91c2VYID0gbW92ZUNsaWVudFg7XHJcbiAgICAgICAgICAgIGxhc3RNb3VzZVkgPSBtb3ZlQ2xpZW50WTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgZnJvbUV2ZW50PE1vdXNlRXZlbnQ+KG92ZXJsYXlFbCwgJ21vdXNldXAnKS5waXBlKHRha2VVbnRpbChzdWIpKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICAgICAgICAvLyDpvKDmoIfmiqzotbflkI7vvIzop6Pnu5Ftb3Zl5ZKMdXDkuovku7ZcclxuICAgICAgICAgICAgc3ViLm5leHQoKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gICAgLy8g5a+56YGu572pRE9N5YGab2JzZXJ2ZeebkeWQrO+8jOS4uuS6huaPkOmrmOaAp+iDve+8jOWPqumcgOimgeebkeWQrOWug+eahOWtkOiKgueCueWPmOWMlu+8iOWinuWKoOaIluWIoOmZpO+8ieWwseihjOS6hu+8jOWtkOiKgueCueWPiuWtkOiKgueCueWQjuS7o+WxnuaAp+aIluiAheWxnuaAp+aUueWPmOaXoOmcgOebkeWQrFxyXG4gICAgLy8g5LiN6ZyA6KaB6K6w5b2V5bGe5oCn5ZKM5pWw5o2u55qE5YmN5ZCO5Y+Y5YyW77yM5omA5Lul6L+ZYXR0cmlidXRlT2xkVmFsdWXlkoxjaGFyYWN0ZXJEYXRhT2xkVmFsdWXpg73orr7nva7kuLpmYWxzZVxyXG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShvdmVybGF5RWwsIHtcclxuICAgICAgc3VidHJlZTogZmFsc2UsIGNoaWxkTGlzdDogdHJ1ZSwgYXR0cmlidXRlT2xkVmFsdWU6IGZhbHNlLFxyXG4gICAgICBjaGFyYWN0ZXJEYXRhT2xkVmFsdWU6IGZhbHNlLCBhdHRyaWJ1dGVzOiBmYWxzZSwgY2hhcmFjdGVyRGF0YTogZmFsc2VcclxuICAgIH0pO1xyXG4gICAgLy8g6aaW5qyh5omT5byA5by556qX77yM5ZCM5qC35Lmf6KaB5omn6KGM5LiL6Z2i55qE5pON5L2cXHJcbiAgICBjb25zdCBtb2RhbFdyYXAgPSBvdmVybGF5RWwucXVlcnlTZWxlY3RvcjxIVE1MRGl2RWxlbWVudD4oYC4ke292ZXJMYXlXcmFwfWApO1xyXG4gICAgY29uc3QgaWRXcmFwID0gbmV3IERhdGUoKS5nZXRUaW1lKCkgKyAnJztcclxuICAgIG1vZGFsV3JhcC5zZXRBdHRyaWJ1dGUoJ29wZW5JZCcsIGlkV3JhcCk7XHJcbiAgICB0aGlzLmRlc3Ryb3lNYXAuc2V0KGlkV3JhcCwgbmV3IFN1YmplY3Q8dm9pZD4oKSk7XHJcbiAgICAvLyDlm6DkuLrmraTml7bigJxkaXYgLmNkay1vdmVybGF5LWNvbnRhaW5lcuKAneeahERPTeW3sue7j+WIm+W7uuWujOW8ueeql+S6hu+8jOS4iumdouebkeWQrG92ZXJsYXlFbOS4jeS8muinpuWPke+8jOaJgOS7pemcgOimgeaJi+WKqOinpuWPkeebkeWQrOS4gOasoVxyXG4gICAgZGVib3VuY2VTdWIubmV4dCgpO1xyXG4gIH1cclxufVxyXG4iXX0=
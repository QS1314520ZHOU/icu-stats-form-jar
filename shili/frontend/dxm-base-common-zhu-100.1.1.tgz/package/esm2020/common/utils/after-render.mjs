import { debounceTime, take } from "rxjs/operators";
import { Observable, Subject } from "rxjs";
export class AfterRender {
    /**
     * @param el  要监听的DOM元素
     * @param fn  DOM改变后要调用的函数
     */
    static finishedFn(el, fn) {
        // 调用 外面回调函数fn的 subject
        const callFnSub = new Subject();
        let runFlag = 0; // 标记位： 判断DOM是否刷新调用了
        // 当DOM刷新调用这个
        const observer = new MutationObserver(() => {
            runFlag += 1; // 只要跑一次，flag不是0
            // obs 就是上面 new 的MutationObserver
            callFnSub.next();
        });
        // 观察这个元素的变化：有三个方面的变化，如true所示
        observer.observe(el, { subtree: true, childList: true, attributes: true });
        // 防抖100ms，此时如果DOM没更新，证明已经渲染完毕
        callFnSub.pipe(debounceTime(100), take(1)).subscribe(() => {
            fn();
            // 执行完毕后，取消监听
            observer?.disconnect();
        });
        // 异常情况： 这里再加个200ms延时，如果DOM不刷新，回调函数也会调用到，外面可以少掉很多判断逻辑
        setTimeout(() => {
            // 200ms之后，执行
            if (runFlag === 0) {
                callFnSub.next();
            }
        }, 200);
    }
    static finishedObs(el) {
        return new Observable(outObs => {
            // 调用 外面回调函数fn的 subject
            const callFnSub = new Subject();
            let runFlag = 0; // 标记位： 判断DOM是否刷新调用了
            // 当DOM刷新调用这个
            const observer = new MutationObserver(() => {
                runFlag += 1; // 只要跑一次，flag不是0
                // obs 就是上面 new 的MutationObserver
                callFnSub.next();
            });
            // 观察这个元素的变化：有三个方面的变化，如true所示
            observer.observe(el, { subtree: true, childList: true, attributes: true });
            // 防抖100ms，此时如果DOM没更新，证明已经渲染完毕
            callFnSub.pipe(debounceTime(100), take(1)).subscribe(() => {
                outObs.next();
                // 执行完毕后，取消监听
                observer?.disconnect();
            });
            // 异常情况： 这里再加个200ms延时，如果DOM不刷新，回调函数也会调用到，外面可以少掉很多判断逻辑
            setTimeout(() => {
                // 200ms之后，执行
                if (runFlag === 0) {
                    callFnSub.next();
                }
            }, 200);
        });
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWZ0ZXItcmVuZGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvZHhtLWJhc2UtY29tbW9uLXpodS9zcmMvY29tbW9uL3V0aWxzL2FmdGVyLXJlbmRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUMsWUFBWSxFQUFFLElBQUksRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQ2xELE9BQU8sRUFBQyxVQUFVLEVBQUUsT0FBTyxFQUFDLE1BQU0sTUFBTSxDQUFDO0FBRXpDLE1BQU0sT0FBTyxXQUFXO0lBRXRCOzs7T0FHRztJQUNILE1BQU0sQ0FBQyxVQUFVLENBQUMsRUFBZSxFQUFFLEVBQWM7UUFDL0MsdUJBQXVCO1FBQ3ZCLE1BQU0sU0FBUyxHQUFrQixJQUFJLE9BQU8sRUFBUSxDQUFDO1FBQ3JELElBQUksT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDLG9CQUFvQjtRQUVyQyxhQUFhO1FBQ2IsTUFBTSxRQUFRLEdBQUcsSUFBSSxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUU7WUFDekMsT0FBTyxJQUFJLENBQUMsQ0FBQyxDQUFDLGdCQUFnQjtZQUM5QixpQ0FBaUM7WUFDakMsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ25CLENBQUMsQ0FBQyxDQUFDO1FBRUgsNkJBQTZCO1FBQzdCLFFBQVEsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDO1FBRXpFLDhCQUE4QjtRQUM5QixTQUFTLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ3hELEVBQUUsRUFBRSxDQUFDO1lBQ0wsYUFBYTtZQUNiLFFBQVEsRUFBRSxVQUFVLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVILHFEQUFxRDtRQUNyRCxVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsYUFBYTtZQUNiLElBQUksT0FBTyxLQUFLLENBQUMsRUFBRTtnQkFDakIsU0FBUyxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2xCO1FBQ0gsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsQ0FBQztJQUVELE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBZTtRQUNoQyxPQUFPLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzdCLHVCQUF1QjtZQUN2QixNQUFNLFNBQVMsR0FBa0IsSUFBSSxPQUFPLEVBQVEsQ0FBQztZQUNyRCxJQUFJLE9BQU8sR0FBRyxDQUFDLENBQUMsQ0FBQyxvQkFBb0I7WUFFckMsYUFBYTtZQUNiLE1BQU0sUUFBUSxHQUFHLElBQUksZ0JBQWdCLENBQUMsR0FBRyxFQUFFO2dCQUN6QyxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO2dCQUM5QixpQ0FBaUM7Z0JBQ2pDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNuQixDQUFDLENBQUMsQ0FBQztZQUVILDZCQUE2QjtZQUM3QixRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQztZQUV6RSw4QkFBOEI7WUFDOUIsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRTtnQkFDeEQsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNkLGFBQWE7Z0JBQ2IsUUFBUSxFQUFFLFVBQVUsRUFBRSxDQUFDO1lBQ3pCLENBQUMsQ0FBQyxDQUFDO1lBRUgscURBQXFEO1lBQ3JELFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsYUFBYTtnQkFDYixJQUFJLE9BQU8sS0FBSyxDQUFDLEVBQUU7b0JBQ2pCLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztpQkFDbEI7WUFDSCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDVixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7ZGVib3VuY2VUaW1lLCB0YWtlfSBmcm9tIFwicnhqcy9vcGVyYXRvcnNcIjtcclxuaW1wb3J0IHtPYnNlcnZhYmxlLCBTdWJqZWN0fSBmcm9tIFwicnhqc1wiO1xyXG5cclxuZXhwb3J0IGNsYXNzIEFmdGVyUmVuZGVyIHtcclxuXHJcbiAgLyoqXHJcbiAgICogQHBhcmFtIGVsICDopoHnm5HlkKznmoRET03lhYPntKBcclxuICAgKiBAcGFyYW0gZm4gIERPTeaUueWPmOWQjuimgeiwg+eUqOeahOWHveaVsFxyXG4gICAqL1xyXG4gIHN0YXRpYyBmaW5pc2hlZEZuKGVsOiBIVE1MRWxlbWVudCwgZm46ICgpID0+IHZvaWQpIHtcclxuICAgIC8vIOiwg+eUqCDlpJbpnaLlm57osIPlh73mlbBmbueahCBzdWJqZWN0XHJcbiAgICBjb25zdCBjYWxsRm5TdWI6IFN1YmplY3Q8dm9pZD4gPSBuZXcgU3ViamVjdDx2b2lkPigpO1xyXG4gICAgbGV0IHJ1bkZsYWcgPSAwOyAvLyDmoIforrDkvY3vvJog5Yik5patRE9N5piv5ZCm5Yi35paw6LCD55So5LqGXHJcblxyXG4gICAgLy8g5b2TRE9N5Yi35paw6LCD55So6L+Z5LiqXHJcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKCgpID0+IHtcclxuICAgICAgcnVuRmxhZyArPSAxOyAvLyDlj6ropoHot5HkuIDmrKHvvIxmbGFn5LiN5pivMFxyXG4gICAgICAvLyBvYnMg5bCx5piv5LiK6Z2iIG5ldyDnmoRNdXRhdGlvbk9ic2VydmVyXHJcbiAgICAgIGNhbGxGblN1Yi5uZXh0KCk7XHJcbiAgICB9KTtcclxuXHJcbiAgICAvLyDop4Llr5/ov5nkuKrlhYPntKDnmoTlj5jljJbvvJrmnInkuInkuKrmlrnpnaLnmoTlj5jljJbvvIzlpoJ0cnVl5omA56S6XHJcbiAgICBvYnNlcnZlci5vYnNlcnZlKGVsLCB7c3VidHJlZTogdHJ1ZSwgY2hpbGRMaXN0OiB0cnVlLCBhdHRyaWJ1dGVzOiB0cnVlfSk7XHJcblxyXG4gICAgLy8g6Ziy5oqWMTAwbXPvvIzmraTml7blpoLmnpxET03msqHmm7TmlrDvvIzor4HmmI7lt7Lnu4/muLLmn5Plrozmr5VcclxuICAgIGNhbGxGblN1Yi5waXBlKGRlYm91bmNlVGltZSgxMDApLCB0YWtlKDEpKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICBmbigpO1xyXG4gICAgICAvLyDmiafooYzlrozmr5XlkI7vvIzlj5bmtojnm5HlkKxcclxuICAgICAgb2JzZXJ2ZXI/LmRpc2Nvbm5lY3QoKTtcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIOW8guW4uOaDheWGte+8miDov5nph4zlho3liqDkuKoyMDBtc+W7tuaXtu+8jOWmguaenERPTeS4jeWIt+aWsO+8jOWbnuiwg+WHveaVsOS5n+S8muiwg+eUqOWIsO+8jOWklumdouWPr+S7peWwkeaOieW+iOWkmuWIpOaWremAu+i+kVxyXG4gICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgIC8vIDIwMG1z5LmL5ZCO77yM5omn6KGMXHJcbiAgICAgIGlmIChydW5GbGFnID09PSAwKSB7XHJcbiAgICAgICAgY2FsbEZuU3ViLm5leHQoKTtcclxuICAgICAgfVxyXG4gICAgfSwgMjAwKTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmaW5pc2hlZE9icyhlbDogSFRNTEVsZW1lbnQpOiBPYnNlcnZhYmxlPGFueT4ge1xyXG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlKG91dE9icyA9PiB7XHJcbiAgICAgIC8vIOiwg+eUqCDlpJbpnaLlm57osIPlh73mlbBmbueahCBzdWJqZWN0XHJcbiAgICAgIGNvbnN0IGNhbGxGblN1YjogU3ViamVjdDx2b2lkPiA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XHJcbiAgICAgIGxldCBydW5GbGFnID0gMDsgLy8g5qCH6K6w5L2N77yaIOWIpOaWrURPTeaYr+WQpuWIt+aWsOiwg+eUqOS6hlxyXG5cclxuICAgICAgLy8g5b2TRE9N5Yi35paw6LCD55So6L+Z5LiqXHJcbiAgICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xyXG4gICAgICAgIHJ1bkZsYWcgKz0gMTsgLy8g5Y+q6KaB6LeR5LiA5qyh77yMZmxhZ+S4jeaYrzBcclxuICAgICAgICAvLyBvYnMg5bCx5piv5LiK6Z2iIG5ldyDnmoRNdXRhdGlvbk9ic2VydmVyXHJcbiAgICAgICAgY2FsbEZuU3ViLm5leHQoKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyDop4Llr5/ov5nkuKrlhYPntKDnmoTlj5jljJbvvJrmnInkuInkuKrmlrnpnaLnmoTlj5jljJbvvIzlpoJ0cnVl5omA56S6XHJcbiAgICAgIG9ic2VydmVyLm9ic2VydmUoZWwsIHtzdWJ0cmVlOiB0cnVlLCBjaGlsZExpc3Q6IHRydWUsIGF0dHJpYnV0ZXM6IHRydWV9KTtcclxuXHJcbiAgICAgIC8vIOmYsuaKljEwMG1z77yM5q2k5pe25aaC5p6cRE9N5rKh5pu05paw77yM6K+B5piO5bey57uP5riy5p+T5a6M5q+VXHJcbiAgICAgIGNhbGxGblN1Yi5waXBlKGRlYm91bmNlVGltZSgxMDApLCB0YWtlKDEpKS5zdWJzY3JpYmUoKCkgPT4ge1xyXG4gICAgICAgIG91dE9icy5uZXh0KCk7XHJcbiAgICAgICAgLy8g5omn6KGM5a6M5q+V5ZCO77yM5Y+W5raI55uR5ZCsXHJcbiAgICAgICAgb2JzZXJ2ZXI/LmRpc2Nvbm5lY3QoKTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvLyDlvILluLjmg4XlhrXvvJog6L+Z6YeM5YaN5Yqg5LiqMjAwbXPlu7bml7bvvIzlpoLmnpxET03kuI3liLfmlrDvvIzlm57osIPlh73mlbDkuZ/kvJrosIPnlKjliLDvvIzlpJbpnaLlj6/ku6XlsJHmjonlvojlpJrliKTmlq3pgLvovpFcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgLy8gMjAwbXPkuYvlkI7vvIzmiafooYxcclxuICAgICAgICBpZiAocnVuRmxhZyA9PT0gMCkge1xyXG4gICAgICAgICAgY2FsbEZuU3ViLm5leHQoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0sIDIwMCk7XHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuIl19
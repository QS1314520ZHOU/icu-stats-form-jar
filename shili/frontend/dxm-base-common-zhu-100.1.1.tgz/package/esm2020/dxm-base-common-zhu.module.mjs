import { NgModule } from '@angular/core';
import { TrustUrlPipe } from "./common/pipes/trust-url.pipe";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import './common/utils/array.extension';
import * as i0 from "@angular/core";
export class CommonLibModule {
}
CommonLibModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CommonLibModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
CommonLibModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CommonLibModule, declarations: [TrustUrlPipe], imports: [CommonModule,
        FormsModule], exports: [TrustUrlPipe] });
CommonLibModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CommonLibModule, providers: [], imports: [[
            CommonModule,
            FormsModule,
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CommonLibModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [TrustUrlPipe],
                    imports: [
                        CommonModule,
                        FormsModule,
                    ],
                    exports: [TrustUrlPipe],
                    providers: []
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHhtLWJhc2UtY29tbW9uLXpodS5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9wcm9qZWN0cy9keG0tYmFzZS1jb21tb24temh1L3NyYy9keG0tYmFzZS1jb21tb24temh1Lm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUMsUUFBUSxFQUFDLE1BQU0sZUFBZSxDQUFDO0FBQ3ZDLE9BQU8sRUFBQyxZQUFZLEVBQUMsTUFBTSwrQkFBK0IsQ0FBQztBQUMzRCxPQUFPLEVBQUMsWUFBWSxFQUFDLE1BQU0saUJBQWlCLENBQUM7QUFDN0MsT0FBTyxFQUFDLFdBQVcsRUFBQyxNQUFNLGdCQUFnQixDQUFDO0FBQzNDLE9BQU8sZ0NBQWdDLENBQUM7O0FBV3hDLE1BQU0sT0FBTyxlQUFlOzs0R0FBZixlQUFlOzZHQUFmLGVBQWUsaUJBUlgsWUFBWSxhQUV6QixZQUFZO1FBQ1osV0FBVyxhQUVILFlBQVk7NkdBR1gsZUFBZSxhQUZmLEVBQUUsWUFMSjtZQUNQLFlBQVk7WUFDWixXQUFXO1NBQ1o7MkZBSVUsZUFBZTtrQkFUM0IsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUUsQ0FBQyxZQUFZLENBQUM7b0JBQzVCLE9BQU8sRUFBRTt3QkFDUCxZQUFZO3dCQUNaLFdBQVc7cUJBQ1o7b0JBQ0QsT0FBTyxFQUFFLENBQUMsWUFBWSxDQUFDO29CQUN2QixTQUFTLEVBQUUsRUFBRTtpQkFDZCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7TmdNb2R1bGV9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtUcnVzdFVybFBpcGV9IGZyb20gXCIuL2NvbW1vbi9waXBlcy90cnVzdC11cmwucGlwZVwiO1xuaW1wb3J0IHtDb21tb25Nb2R1bGV9IGZyb20gXCJAYW5ndWxhci9jb21tb25cIjtcbmltcG9ydCB7Rm9ybXNNb2R1bGV9IGZyb20gXCJAYW5ndWxhci9mb3Jtc1wiO1xuaW1wb3J0ICcuL2NvbW1vbi91dGlscy9hcnJheS5leHRlbnNpb24nO1xuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtUcnVzdFVybFBpcGVdLFxuICBpbXBvcnRzOiBbXG4gICAgQ29tbW9uTW9kdWxlLFxuICAgIEZvcm1zTW9kdWxlLFxuICBdLFxuICBleHBvcnRzOiBbVHJ1c3RVcmxQaXBlXSxcbiAgcHJvdmlkZXJzOiBbXVxufSlcbmV4cG9ydCBjbGFzcyBDb21tb25MaWJNb2R1bGUge1xufVxuIl19
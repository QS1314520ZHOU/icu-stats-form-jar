import './common/utils/array.extension';
import * as i0 from "@angular/core";
import * as i1 from "./common/pipes/trust-url.pipe";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
export declare class CommonLibModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonLibModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CommonLibModule, [typeof i1.TrustUrlPipe], [typeof i2.CommonModule, typeof i3.FormsModule], [typeof i1.TrustUrlPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CommonLibModule>;
}

import * as i0 from '@angular/core';
import { Pipe, NgModule } from '@angular/core';
import * as i1 from '@angular/platform-browser';
import { CommonModule, DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import * as _ from 'lodash';
import dayjs from 'dayjs';
import { debounceTime, take, takeUntil } from 'rxjs/operators';
import { Subject, Observable, fromEvent, of, EMPTY } from 'rxjs';
import { Subject as Subject$1 } from 'rxjs/internal/Subject';

class TrustUrlPipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(base64) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(base64);
    }
}
TrustUrlPipe.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: TrustUrlPipe, deps: [{ token: i1.DomSanitizer }], target: i0.ɵɵFactoryTarget.Pipe });
TrustUrlPipe.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: TrustUrlPipe, name: "trustUrl" });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: TrustUrlPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'trustUrl'
                }]
        }], ctorParameters: function () { return [{ type: i1.DomSanitizer }]; } });

// 在数组最前面增加
Array.prototype.addToFront = function (one) {
    if (!one) {
        return false;
    }
    if (this.indexOf(one) < 0) {
        // 没有就加
        this.unshift(one);
        return true;
    }
    return false;
};
// 删除一个元素, 按值
Array.prototype.remove = function (o) {
    return _.remove(this, (n) => {
        return n === o;
    });
};
// 删除一个元素, 按index
Array.prototype.removeAt = function (index) {
    return this.splice(index, 1);
};
// 删除多个, 按值
Array.prototype.removeSome = function (o) {
    return _.pullAll(this, o);
};
// 删除多个, 按index
Array.prototype.removeSomeAt = function (indexs) {
    return _.pullAt(this, indexs);
};
// 在指定位置插入一个元素，todo，返回值是否有问题，原数组是否改变
Array.prototype.addAt = function (index, one) {
    if (!one) {
        return false;
    }
    const l = this.length;
    if (index >= l || index < 0) {
        return false;
    }
    if (this.indexOf(one) < 0) {
        // 没有就加
        // 产生新的素组，拉取后面，自己不变
        const end = this.slice(index);
        // 截取后面，自己变
        this.splice(index, l - index);
        this.push(one);
        this.push(...end);
        return true;
    }
    return false;
};
// 在指定位置插入一个元素，空就不插入了，有也不插入（不重复插入，这是默认的思维）
Array.prototype.add = function (one) {
    if (!one) {
        return false;
    }
    if (this.indexOf(one) < 0) {
        // 没有就加
        this.push(one);
        return true;
    }
    return false;
};
// 清空数组
Array.prototype.clear = function () {
    return this.splice(0);
};
// 是否包含元素
Array.prototype.has = function (one) {
    if (this.indexOf(one) < 0) {
        return false;
    }
    return true;
};

class CommonLibModule {
}
CommonLibModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CommonLibModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
CommonLibModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CommonLibModule, declarations: [TrustUrlPipe], imports: [CommonModule,
        FormsModule], exports: [TrustUrlPipe] });
CommonLibModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CommonLibModule, providers: [], imports: [[
            CommonModule,
            FormsModule,
        ]] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "13.4.0", ngImport: i0, type: CommonLibModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [TrustUrlPipe],
                    imports: [
                        CommonModule,
                        FormsModule,
                    ],
                    exports: [TrustUrlPipe],
                    providers: []
                }]
        }] });

/*
 * Created by 朱穗辉 on 2022/9/15 9:30.
 * Copyright (c) 深医信息技术（深圳）有限公司
 */
/**
 * 返回格式化数字, 数字为整数返回不带0, 不为整数则会补位小数0
 * @param val 原值
 * @param floatCount 格式化指定小数位
 */
function getDecimalFormat(val, floatCount) {
    // 四舍五入
    const _num = getNum45(val, floatCount);
    let _str = '';
    // 是整数
    if (isInteger(_num)) {
        _str = _num.toString();
    }
    // 不是整数
    else {
        // 补零
        _str = _num.toFixed(floatCount).toString();
    }
    return _str;
}
/**
 * 取得四舍五入后的浮点数
 * @param val 原值
 * @param floatCount 四舍五入小数位
 */
function getNum45(val, floatCount) {
    val = Math.round(val * Math.pow(10, floatCount)) / Math.pow(10, floatCount);
    return val;
}
/**
 * 判断是否整数
 * @param val 待判断值
 */
function isInteger(val) {
    return val % 1 === 0;
}
function makeUUIDString() {
    let outString = '';
    const inOptions = "abcdefghijklmnopqrstuvwxyz0123456789";
    for (let i = 0; i < 15; i++) {
        outString += inOptions.charAt(Math.floor(Math.random() * inOptions.length));
    }
    return outString + (new Date().getTime());
}
// 判断是否包含中文
function isChina(str) {
    const reg = new RegExp("[\\u4E00-\\u9FFF]+", "g");
    return reg.test(str);
}
// 后端的日期格式跟前端的不一样，坑爹啊，这里还要做一层转换
function formatTransform(str) {
    return str.replace(new RegExp('y', 'g'), 'Y').replace(new RegExp('d', 'g'), 'D');
}
function isDef(val) {
    return val !== null && val !== undefined;
}
function isNOTDef(val) {
    return !isDef(val);
}
// 判断字符串是否不为空（为null、undefined、''返回false，其他返回true）
function isHasVal(val) {
    return typeof val !== 'string' ? isDef(val) : val.trim() !== '';
}
// 判断是否为空或者是空字符串（为null、undefined、''返回true，其他返回false）
function isNoVal(val) {
    return typeof val === 'string' ? val.trim() === '' : !isDef(val);
}
/**
 * 裁切字符串
 * @param str 输入原始字符串
 * @param limit 裁切后的长度
 */
function strLimit(str, limit) {
    let newStr = '';
    if (str !== '' && str != null) {
        const arr = str.split('');
        if (arr.length > limit) {
            for (let i = 0; i < limit; i++) {
                newStr += arr[i];
            }
            return newStr + '...';
        }
    }
    return str;
}
/**
 * 公共方法
 * 判断字符串是否在数组中出现
 * @param str 字符串
 * @param arr 数组
 */
function isItemInArr(str, arr) {
    if (arr.length > 0) {
        for (const item of arr) {
            if (item === str) {
                return true;
            }
        }
    }
    return false;
}
/**
 * 字符串转unicode (正则表达查询需要把中文转unicode)
 * @param str 待转码字符串
 */
function strToUnicode(str) {
    let unicodeStr = '';
    if (str != null && str.length > 0) {
        const _arr = str.split('');
        for (const item of _arr) {
            unicodeStr += cnToUnicode(item);
        }
    }
    return unicodeStr;
}
/**
 * 单个中文字符转unicode
 * @param cn 单个中文字符
 */
function cnToUnicode(cn) {
    return '\\u' + cn.charCodeAt(0).toString(16);
}
/**
 * Base64解码--（xiao)
 */
function base64Decode(input) {
    const keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    // tslint:disable-next-line
    let output = "", chr1, chr2, chr3, enc1, enc2, enc3, enc4, i = 0;
    input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
    while (i < input.length) {
        enc1 = keyStr.indexOf(input.charAt(i++));
        enc2 = keyStr.indexOf(input.charAt(i++));
        enc3 = keyStr.indexOf(input.charAt(i++));
        enc4 = keyStr.indexOf(input.charAt(i++));
        // tslint:disable-next-line
        chr1 = (enc1 << 2) | (enc2 >> 4);
        // tslint:disable-next-line
        chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
        // tslint:disable-next-line
        chr3 = ((enc3 & 3) << 6) | enc4;
        output = output + String.fromCharCode(chr1);
        if (enc3 !== 64) {
            output = output + String.fromCharCode(chr2);
        }
        if (enc4 !== 64) {
            output = output + String.fromCharCode(chr3);
        }
    }
    output = utf8Decode(output);
    return output;
}
function base64Encode(input) {
    const keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    // tslint:disable-next-line:one-variable-per-declaration
    let output = "", chr1, chr2, chr3, enc1, enc2, enc3, enc4, i = 0;
    input = utf8Encode(input);
    while (i < input.length) {
        chr1 = input.charCodeAt(i++);
        chr2 = input.charCodeAt(i++);
        chr3 = input.charCodeAt(i++);
        // tslint:disable-next-line:no-bitwise
        enc1 = chr1 >> 2;
        // tslint:disable-next-line:no-bitwise
        enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
        // tslint:disable-next-line:no-bitwise
        enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
        // tslint:disable-next-line:no-bitwise
        enc4 = chr3 & 63;
        if (isNaN(chr2)) {
            enc3 = enc4 = 64;
        }
        else if (isNaN(chr3)) {
            enc4 = 64;
        }
        output = output +
            keyStr.charAt(enc1) + keyStr.charAt(enc2) +
            keyStr.charAt(enc3) + keyStr.charAt(enc4);
    }
    return output;
}
function utf8Encode(str) {
    str = str.replace(/\r\n/g, "\n");
    let utftext = "";
    for (let n = 0; n < str.length; n++) {
        const c = str.charCodeAt(n);
        if (c < 128) {
            utftext += String.fromCharCode(c);
        }
        else if ((c > 127) && (c < 2048)) {
            // tslint:disable-next-line:no-bitwise
            utftext += String.fromCharCode((c >> 6) | 192);
            // tslint:disable-next-line:no-bitwise
            utftext += String.fromCharCode((c & 63) | 128);
        }
        else {
            // tslint:disable-next-line:no-bitwise
            utftext += String.fromCharCode((c >> 12) | 224);
            // tslint:disable-next-line:no-bitwise
            utftext += String.fromCharCode(((c >> 6) & 63) | 128);
            // tslint:disable-next-line:no-bitwise
            utftext += String.fromCharCode((c & 63) | 128);
        }
    }
    return utftext;
}
/**
 * UTF-8解码--（xiao)
 */
function utf8Decode(utftext) {
    // tslint:disable-next-line
    let string = "", i = 0, c = 0, c2 = 0, c3 = 0;
    while (i < utftext.length) {
        c = utftext.charCodeAt(i);
        if (c < 128) {
            string += String.fromCharCode(c);
            i++;
        }
        else if ((c > 191) && (c < 224)) {
            c2 = utftext.charCodeAt(i + 1);
            // tslint:disable-next-line
            string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
            i += 2;
        }
        else {
            c2 = utftext.charCodeAt(i + 1);
            c3 = utftext.charCodeAt(i + 2);
            // tslint:disable-next-line
            string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
            i += 3;
        }
    }
    return string;
}
// c 参数：表示要被转化的容量大小，以字节为单
// b 参数：表示如果转换时出小数，四舍五入保留多少位 默认为2位小数
function formatBytes(size, b = 2) {
    if (0 === size) {
        return "0 B";
    }
    const c = 1024;
    const d = b || 2;
    const e = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    const f = Math.floor(Math.log(size) / Math.log(c));
    return parseFloat((size / Math.pow(c, f)).toFixed(d)) + " " + e[f];
}
function dateTransformStr(date, format) {
    return new DatePipe("zh-CN").transform(date, format);
}

/**
 * 日期工具方法集合
 * Created by Jeremy 2023-02-08 16:20:58
 * Copyright by 深医信息技术（深圳）有限公司
 *
 */
// 日期工具
/**
 * 判断d1是否在d2之前
 * @param d1 日期1
 * @param d2 日期2
 */
function before(d1, d2, equals = false) {
    // 有一个人为空, 判断不成立
    if (hasNotDef(d1, d2)) {
        return false;
    }
    const m1 = getMillisOf(d1);
    const m2 = getMillisOf(d2);
    return equals ? m1 <= m2 : m1 < m2;
}
/**
 * 判断d1是否在d2之后
 * @param d1 日期1
 * @param d2 日期2
 */
function after(d1, d2, equals = false) {
    // 有一个人为空, 判断不成立
    if (hasNotDef(d1, d2)) {
        return false;
    }
    const m1 = getMillisOf(d1);
    const m2 = getMillisOf(d2);
    return equals ? m1 >= m2 : m1 > m2;
}
function hasNotDef(...d) {
    for (const t of d) {
        if (!isDef(t)) {
            return true;
        }
    }
    return false;
}
function getDate(d) {
    return d instanceof Date ? d : new Date(d);
}
function getMillisOf(date) {
    if (typeof date === 'number') {
        return date;
    }
    return date.getTime();
}
function zeroSecAndMs(date) {
    if (hasNotDef(date)) {
        return null;
    }
    return dayjs(getDate(date)).second(0).millisecond(0).toDate();
}

/*
* Created by 唐钦洪 2023-01-31 15:53:36
* Copyright by 深医信息技术（深圳）有限公司
*/
/**
 * 按照当前日期获取岁数
 * @param dob    出生日期
 */
function getAge(dob) {
    return getIntAge(dob, new Date().getTime());
}
/**
 * 根据传入的时间获取岁数
 * @param dob    出生日期
 * @param inRoomTime  入手术室时间
 */
function getIntAge(dob, inRoomTime) {
    const time = dayjs(inRoomTime);
    const yearNow = time.get('year');
    const monthNow = time.get('month') + 1;
    const dayOfMonthNow = time.date();
    const dobTime = dayjs(dob);
    const yearBirth = dobTime.get('year');
    const monthBirth = dobTime.get('month') + 1;
    const dayOfMonthBirth = time.date();
    let age_year = yearNow - yearBirth;
    let age_month = monthNow - monthBirth;
    const age_day = dayOfMonthNow - dayOfMonthBirth;
    if (age_day < 0) {
        age_month--;
    }
    if (age_month < 0) {
        age_year--;
    }
    return age_year;
}

class AfterRender {
    /**
     * @param el  要监听的DOM元素
     * @param fn  DOM改变后要调用的函数
     */
    static finishedFn(el, fn) {
        // 调用 外面回调函数fn的 subject
        const callFnSub = new Subject();
        let runFlag = 0; // 标记位： 判断DOM是否刷新调用了
        // 当DOM刷新调用这个
        const observer = new MutationObserver(() => {
            runFlag += 1; // 只要跑一次，flag不是0
            // obs 就是上面 new 的MutationObserver
            callFnSub.next();
        });
        // 观察这个元素的变化：有三个方面的变化，如true所示
        observer.observe(el, { subtree: true, childList: true, attributes: true });
        // 防抖100ms，此时如果DOM没更新，证明已经渲染完毕
        callFnSub.pipe(debounceTime(100), take(1)).subscribe(() => {
            fn();
            // 执行完毕后，取消监听
            observer === null || observer === void 0 ? void 0 : observer.disconnect();
        });
        // 异常情况： 这里再加个200ms延时，如果DOM不刷新，回调函数也会调用到，外面可以少掉很多判断逻辑
        setTimeout(() => {
            // 200ms之后，执行
            if (runFlag === 0) {
                callFnSub.next();
            }
        }, 200);
    }
    static finishedObs(el) {
        return new Observable(outObs => {
            // 调用 外面回调函数fn的 subject
            const callFnSub = new Subject();
            let runFlag = 0; // 标记位： 判断DOM是否刷新调用了
            // 当DOM刷新调用这个
            const observer = new MutationObserver(() => {
                runFlag += 1; // 只要跑一次，flag不是0
                // obs 就是上面 new 的MutationObserver
                callFnSub.next();
            });
            // 观察这个元素的变化：有三个方面的变化，如true所示
            observer.observe(el, { subtree: true, childList: true, attributes: true });
            // 防抖100ms，此时如果DOM没更新，证明已经渲染完毕
            callFnSub.pipe(debounceTime(100), take(1)).subscribe(() => {
                outObs.next();
                // 执行完毕后，取消监听
                observer === null || observer === void 0 ? void 0 : observer.disconnect();
            });
            // 异常情况： 这里再加个200ms延时，如果DOM不刷新，回调函数也会调用到，外面可以少掉很多判断逻辑
            setTimeout(() => {
                // 200ms之后，执行
                if (runFlag === 0) {
                    callFnSub.next();
                }
            }, 200);
        });
    }
}

/*
*   实现弹窗拖动的类
*   因为这是全局实现拖拽事件，所以observeModalOpen函数就算多次调用也只会生效一次
* Created by 唐钦洪 2024-05-14 15:02:01
* Copyright by 深医信息技术（深圳）有限公司
*/
class ModalDrag {
    // modal弹窗拖拽移动
    static observeModalDrag() {
        // 已经被调用过了，则下次如果有再调用，不给执行后面步骤了
        if (this.isStart) {
            throw new Error('该函数只允许调用一次，请不要重复调用');
        }
        this.isStart = true;
        const bodyObserver = new MutationObserver((mutations) => {
            var _a;
            for (const record of mutations) {
                const isAddNodeFlag = (record.type === 'childList' && ((_a = record.addedNodes) === null || _a === void 0 ? void 0 : _a.length) > 0);
                if (!isAddNodeFlag) {
                    continue;
                }
                const overlayEl = document.querySelector('.cdk-overlay-container');
                if (!isDef(overlayEl)) {
                    continue;
                }
                // 弹窗的DOM容器创建出来了，则不用再进行监听了
                bodyObserver.disconnect();
                // 直接监听弹窗事件
                this.modalBindEventAndListen();
                break;
            }
        });
        // 只监听body节点下有没有新的子元素生成，其他的都不需要监听，所以都设置成false
        bodyObserver.observe(document.body, {
            subtree: false, childList: true, attributeOldValue: false,
            characterDataOldValue: false, attributes: false, characterData: false
        });
    }
    static modalBindEventAndListen() {
        const overlayEl = document.querySelector('.cdk-overlay-container');
        const debounceSub = new Subject$1();
        const overLayWrap = 'cdk-global-overlay-wrapper';
        const observer = new MutationObserver((mutations) => {
            mutations.forEach(record => {
                record.addedNodes.forEach(addedNode => {
                    const el = addedNode;
                    // 有这个class类，证明此时是打开了一个新的弹窗，那么需要添加新的Subject，方便后续移除事件用
                    if (el.classList.contains(overLayWrap)) {
                        const id = new Date().getTime() + '';
                        el.setAttribute('openId', id);
                        this.destroyMap.set(id, new Subject$1());
                        return;
                    }
                });
                record.removedNodes.forEach(node => {
                    const openId = node.getAttribute('openId');
                    // 有id，证明此时关闭并销毁了某个弹窗，那么这个弹窗的鼠标事件也要移除
                    if (isDef(openId)) {
                        this.destroyMap.get(openId).next();
                        this.destroyMap.delete(openId);
                        return;
                    }
                });
            });
            const modalElList = overlayEl.querySelectorAll(`.${overLayWrap}`);
            // modalElList为0，证明此时是关闭弹窗操作，无需再对弹窗做事件绑定操作
            if (!isDef(modalElList) || modalElList.length === 0) {
                return;
            }
            debounceSub.next();
        });
        // DOM修改会很频繁，需要做一个防抖，设置1s吧，如果时间设置太小，有可能导致弹窗内容还没显示出来，
        // 下面获取弹窗宽度时，有可能得到错误的宽度，导致计算left值出现变差，故时间设置久点，弹窗内容基本渲染出来，此时再得到的宽度就比较正确
        debounceSub.pipe(debounceTime(1000)).subscribe(() => {
            // 这是弹窗最外层的DOM元素，操作这个DOM的left和top，就能实现拖拽效果了
            // 要获取所有的弹窗，因为可能有多个，比如：弹窗里面还能再打开弹窗
            const modalElList = overlayEl.querySelectorAll(`.${overLayWrap}`);
            modalElList.forEach(modal => {
                const modalOpenId = modal.getAttribute('openId');
                const modalEl = modal.querySelector(`div[role='document'].ant-modal`);
                // 原来不是fix定位，现在手动设置弹窗为fix定位，这样拖拽时，就能计算出拖动的距离，并重新设置left和top值了
                if (modalEl.style.position !== 'fixed') {
                    modalEl.style.position = 'fixed';
                    // 原来弹窗有个下边距，好像没啥卵用，干掉它吧
                    modalEl.style.paddingBottom = '0px';
                    const pxWidth = modalEl.getBoundingClientRect().width;
                    // left值等于视窗宽度的一半 - 弹窗宽度的一半
                    modalEl.style.left = `${document.documentElement.clientWidth / 2 - pxWidth / 2}px`;
                }
                const headEl = modalEl.querySelector('.ant-modal-header');
                if (!isDef(headEl)) {
                    return;
                }
                // 设置弹窗标题DOM为拖拽图标样式
                headEl.style.cursor = 'move';
                // 弹窗标题DOM已经绑定事件了，不需要再绑定直接返回
                const bindEvent = headEl.getAttribute('bindEvent');
                if (isHasVal(bindEvent)) {
                    return;
                }
                headEl.setAttribute('bindEvent', 'true');
                // 开始给标题DOM绑定拖拽事件
                fromEvent(headEl, 'mousedown').pipe(takeUntil(this.destroyMap.get(modalOpenId))).subscribe(event => {
                    let lastMouseX = event.clientX;
                    let lastMouseY = event.clientY;
                    const sub = new Subject$1();
                    // move和up事件应该绑定在全屏遮罩层的DOM上
                    fromEvent(overlayEl, 'mousemove').pipe(takeUntil(sub)).subscribe((moveEvent) => {
                        const moveClientX = moveEvent.clientX;
                        const moveClientY = moveEvent.clientY;
                        const oriLeft = modalEl.getBoundingClientRect().left;
                        const oriTop = modalEl.getBoundingClientRect().top;
                        let left;
                        let top;
                        if (lastMouseX > moveClientX) {
                            left = oriLeft - Math.abs(lastMouseX - moveClientX);
                        }
                        else {
                            left = oriLeft + Math.abs(lastMouseX - moveClientX);
                        }
                        if (lastMouseY > moveClientY) {
                            top = oriTop - Math.abs(lastMouseY - moveClientY);
                        }
                        else {
                            top = oriTop + Math.abs(lastMouseY - moveClientY);
                        }
                        // left = (left < 0 ? 0 : left);
                        top = (top < 0 ? 0 : top);
                        modalEl.style.left = `${left}px`;
                        modalEl.style.top = `${top}px`;
                        lastMouseX = moveClientX;
                        lastMouseY = moveClientY;
                    });
                    fromEvent(overlayEl, 'mouseup').pipe(takeUntil(sub)).subscribe(() => {
                        // 鼠标抬起后，解绑move和up事件
                        sub.next();
                    });
                });
            });
        });
        // 对遮罩DOM做observe监听，为了提高性能，只需要监听它的子节点变化（增加或删除）就行了，子节点及子节点后代属性或者属性改变无需监听
        // 不需要记录属性和数据的前后变化，所以这attributeOldValue和characterDataOldValue都设置为false
        observer.observe(overlayEl, {
            subtree: false, childList: true, attributeOldValue: false,
            characterDataOldValue: false, attributes: false, characterData: false
        });
        // 首次打开弹窗，同样也要执行下面的操作
        const modalWrap = overlayEl.querySelector(`.${overLayWrap}`);
        const idWrap = new Date().getTime() + '';
        modalWrap.setAttribute('openId', idWrap);
        this.destroyMap.set(idWrap, new Subject$1());
        // 因为此时“div .cdk-overlay-container”的DOM已经创建完弹窗了，上面监听overlayEl不会触发，所以需要手动触发监听一次
        debounceSub.next();
    }
}
// 用来存储当前所有已打开弹窗的Map，主要用来实现弹窗销毁时取消该弹窗的鼠标事件
// key是id，value是事件监听的subject
ModalDrag.destroyMap = new Map();

/**
 * Created by 刘云飞 on 2023/2/8
 * Copyright by 深医信息技术（深圳）有限公司
 */
class BedsideConstants {
}
BedsideConstants.PARAM_IBP_S = "param_ibp_s";
BedsideConstants.PARAM_IBP_D = "param_ibp_d";
BedsideConstants.PARAM_IBP_M = "param_ibp_m";
BedsideConstants.PARAM_NIBP_S = "param_nibp_s";
BedsideConstants.PARAM_NIBP_D = "param_nibp_d";
BedsideConstants.PARAM_NIBP_M = "param_nibp_m";
BedsideConstants.PARAM_RESP = "param_resp";
BedsideConstants.PARAM_RESP_CTRL = "param_resp_ctrl";
BedsideConstants.PARAM_RESP_FUZHU = "param_resp_fuzhu";
BedsideConstants.PARAM_BLOOD_BGA_Y = "param_BLOOD_BGA_Y";

class Color {
    /**
     * @param r Red component.
     * @param g Green component.
     * @param b Blue component.
     * @param a Alpha (opacity) component. 透明度，0到255，千万别写1（很透明的了），也别写100
     */
    constructor(r, g, b, a) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.a = a;
        if (isDef(this.a)) {
            this.alpha = this.a / 255;
        }
    }
    /**
     * 字符串转成颜色
     * 颜色字符串支持十六进制和 RGB(RGBA)格式
     * @param str: 颜色字符串
     */
    static fromString(str) {
        let color = this.fromHexString(str);
        if (isDef(color))
            return color;
        return this.fromRgbaString(str);
    }
    /**
     * 将十六进制的颜色字符串转换成颜色
     * @param str: 颜色字符串。eg: #FF00FF
     */
    static fromHexString(str) {
        if (!isDef(str))
            return null;
        str = str.trim();
        if (!str.startsWith("#") || str.length < 7)
            return null;
        let rgb = str.substring(1);
        const r = Number.parseInt(rgb.substring(0, 2), 16);
        const g = Number.parseInt(rgb.substring(2, 4), 16);
        const b = Number.parseInt(rgb.substring(4, 6), 16);
        let a = undefined;
        if (rgb.length > 6) {
            a = Number.parseInt(rgb.substring(6), 16);
        }
        return new Color(r, g, b, a);
    }
    /**
     * 将 RGB 或 RGBA 格式的颜色字符串转换成颜色
     * @param str: 颜色字符串。eg: rgba(255, 255, 255, 255)、rgb(255, 0, 255)
     */
    static fromRgbaString(str) {
        if (!isDef(str))
            return null;
        str = str.trim();
        if (!str.startsWith("rgb"))
            return null;
        let rgbaStr = str.substring(str.indexOf("(") + 1, str.indexOf(")"));
        let rgba = rgbaStr.split(",");
        if (rgba.length < 3 || rgba.length > 4)
            return null;
        const r = Number.parseInt(rgba[0].trim());
        const g = Number.parseInt(rgba[1].trim());
        const b = Number.parseInt(rgba[2].trim());
        let a = undefined;
        if (rgba.length === 4) {
            a = Number.parseFloat(rgba[3].trim());
        }
        return new Color(r, g, b, a);
    }
    toString() {
        if (isDef(this.a)) {
            return "#" + this.toHexString(this.r) + this.toHexString(this.g) + this.toHexString(this.b) + this.toHexString(this.a);
        }
        return "#" + this.toHexString(this.r) + this.toHexString(this.g) + this.toHexString(this.b);
    }
    /**
     * 将十进制数转成十六进制，不足两位前面补0
     * @param num
     */
    toHexString(num) {
        let str = num.toString(16);
        if (str.length < 2) {
            return "0" + str;
        }
        return str;
    }
    toUpCaseString() {
        return this.toString().toUpperCase();
    }
    toRgbaString() {
        if (isDef(this.a)) {
            return "rgba(" + this.r + ", " + this.g + ", " + this.b + ", " + this.a + ")";
        }
        return "rgb(" + this.r + ", " + this.g + ", " + this.b + ")";
    }
    clone() {
        return new Color(this.r, this.g, this.b, this.a);
    }
}
/**
 * The color white.  In the default sRGB space.
 */
Color.white = new Color(255, 255, 255);
Color.WHITE = Color.white;
/**
 * The color light gray.  In the default sRGB space.
 */
Color.lightGray = new Color(192, 192, 192);
Color.LIGHT_GRAY = Color.lightGray;
/**
 * The color gray.  In the default sRGB space.
 */
Color.gray = new Color(128, 128, 128);
Color.GRAY = Color.gray;
/**
 * The color dark gray.  In the default sRGB space.
 */
Color.darkGray = new Color(64, 64, 64);
Color.DARK_GRAY = Color.darkGray;
/**
 * The color black.  In the default sRGB space.
 */
Color.black = new Color(0, 0, 0);
Color.BLACK = Color.black;
/**
 * The color red.  In the default sRGB space.
 */
Color.red = new Color(255, 0, 0);
Color.RED = Color.red;
/**
 * The color pink.  In the default sRGB space.
 */
Color.pink = new Color(255, 175, 175);
Color.PINK = Color.pink;
/**
 * The color orange.  In the default sRGB space.
 */
Color.orange = new Color(255, 200, 0);
Color.ORANGE = Color.orange;
/**
 * The color yellow.  In the default sRGB space.
 */
Color.yellow = new Color(255, 255, 0);
Color.YELLOW = Color.yellow;
/**
 * The color green.  In the default sRGB space.
 */
Color.green = new Color(0, 255, 0);
Color.GREEN = Color.green;
/**
 * The color magenta.  In the default sRGB space.
 */
Color.magenta = new Color(255, 0, 255);
Color.MAGENTA = Color.magenta;
/**
 * The color cyan.  In the default sRGB space.
 */
Color.cyan = new Color(0, 255, 255);
Color.CYAN = Color.cyan;
/**
 * The color blue.  In the default sRGB space.
 */
Color.blue = new Color(0, 0, 255);
Color.BLUE = Color.blue;
/**
 * The color Navy Blue.  In the default sRGB space.
 */
Color.navyblue = new Color(26, 115, 168);
Color.NAVYBLUE = Color.navyblue;

/*
* Created by 姚念德 2023-01-31 15:21:51
* Copyright by 深医信息技术（深圳）有限公司
*/
class SwingConstants {
}
SwingConstants.CENTER = 0;
//
// Box-orientation constant used to specify locations in a box.
//
/**
 * Box-orientation constant used to specify the top of a box.
 */
SwingConstants.TOP = 1;
/**
 * Box-orientation constant used to specify the left side of a box.
 */
SwingConstants.LEFT = 2;
/**
 * Box-orientation constant used to specify the bottom of a box.
 */
SwingConstants.BOTTOM = 3;
/**
 * Box-orientation constant used to specify the right side of a box.
 */
SwingConstants.RIGHT = 4;
//
// Compass-direction myConstant used to specify a position.
//
/**
 * Compass-direction North (up).
 */
SwingConstants.NORTH = 1;
/**
 * Compass-direction north-east (upper right).
 */
SwingConstants.NORTH_EAST = 2;
/**
 * Compass-direction east (right).
 */
SwingConstants.EAST = 3;
/**
 * Compass-direction south-east (lower right).
 */
SwingConstants.SOUTH_EAST = 4;
/**
 * Compass-direction south (down).
 */
SwingConstants.SOUTH = 5;
/**
 * Compass-direction south-west (lower left).
 */
SwingConstants.SOUTH_WEST = 6;
/**
 * Compass-direction west (left).
 */
SwingConstants.WEST = 7;
/**
 * Compass-direction north west (upper left).
 */
SwingConstants.NORTH_WEST = 8;

class MyFont {
    static customFontString(fontSize = 18, fontType = MyFont.FONT_YA_HEI, fontStyle = MyFont.STYLE_NORMAL) {
        return `${fontStyle} ${fontSize}px ${fontType}`;
    }
    // 传入配置，获取字体字符串
    static getFontStrByCompPojo(fontSize, fontName) {
        // 如果是宋体，那么改用新宋体
        if (fontName === MyFont.FONT_SONG) {
            fontName = MyFont.FONT_NEW_SONG;
        }
        return `normal ${fontSize}px ${fontName}`;
    }
}
MyFont.FONT_YA_HEI = '微软雅黑';
MyFont.FONT_NEW_SONG = '新宋体';
MyFont.FONT_SONG = "宋体";
MyFont.FONT_ARIAL = "Arial";
MyFont.FONT_ARIAL_NARROW = "Arial Narrow";
MyFont.FONT_TIMES_NEW_ROMAN = "Times New Roman"; // 这个不能用
MyFont.FONT_CONSOLAS = "Consolas"; // 这个是打钩用
MyFont.STYLE_BOLD = "bold";
MyFont.STYLE_NORMAL = "normal";
MyFont.STYLE_ITALIC = "italic";
MyFont.STYLE_OBLIQUE = "oblique";
MyFont.ARIAL_22 = MyFont.customFontString(22, MyFont.FONT_ARIAL);
MyFont.ARIAL_16 = MyFont.customFontString(16, MyFont.FONT_ARIAL);
MyFont.ARIAL_18 = MyFont.customFontString(18, MyFont.FONT_ARIAL);
MyFont.NEW_SONG_10 = MyFont.customFontString(10, MyFont.FONT_NEW_SONG);
MyFont.NEW_SONG_11 = MyFont.customFontString(11, MyFont.FONT_NEW_SONG);
MyFont.NEW_SONG_12 = MyFont.customFontString(12, MyFont.FONT_NEW_SONG);
MyFont.NEW_SONG_13 = MyFont.customFontString(13, MyFont.FONT_NEW_SONG);
MyFont.NEW_SONG_14 = MyFont.customFontString(14, MyFont.FONT_NEW_SONG);
MyFont.NEW_SONG_BOLD_14 = MyFont.customFontString(14, MyFont.FONT_NEW_SONG, MyFont.STYLE_BOLD);
MyFont.NEW_SONG_15 = MyFont.customFontString(15, MyFont.FONT_NEW_SONG);
MyFont.NEW_SONG_16 = MyFont.customFontString(16, MyFont.FONT_NEW_SONG);
MyFont.NEW_SONG_17 = MyFont.customFontString(17, MyFont.FONT_NEW_SONG);
MyFont.NEW_SONG_18 = MyFont.customFontString(18, MyFont.FONT_NEW_SONG);
MyFont.YA_HEI_10 = MyFont.customFontString(10, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_11 = MyFont.customFontString(11, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_12 = MyFont.customFontString(12, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_13 = MyFont.customFontString(13, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_14 = MyFont.customFontString(14, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_15 = MyFont.customFontString(15, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_16 = MyFont.customFontString(16, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_17 = MyFont.customFontString(17, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_18 = MyFont.customFontString(18, MyFont.FONT_YA_HEI);
MyFont.YA_HEI_19 = MyFont.customFontString(19, MyFont.FONT_YA_HEI);
MyFont.CONSOLAS_18 = MyFont.customFontString(18, MyFont.FONT_YA_HEI);

/*
* Created by 姚念德 2023-01-31 13:57:12
* Copyright by 深医信息技术（深圳）有限公司
*/
class MyDateFormat {
}
MyDateFormat.DATE_FORMAT_STR_Y = "yyyy";
MyDateFormat.DATE_FORMAT_STR_M = "MM";
MyDateFormat.DATE_FORMAT_STR_D = "dd";
MyDateFormat.DATE_FORMAT_STR_HM = "HH:mm";
MyDateFormat.DATE_FORMAT_STR_hh = "HH";
MyDateFormat.DATE_FORMAT_STR_mm = "mm";
MyDateFormat.DATE_FORMAT_STR_YMDHMS = "yyyy-MM-dd HH:mm:ss";
MyDateFormat.DATE_FORMAT_STR_YMDHMS_ = "yyyy/MM/dd HH:mm:ss";
MyDateFormat.DATE_FORMAT_STR_YMDHMSsss = "yyyy-MM-dd HH:mm:ss.SSS";
MyDateFormat.DATE_FORMAT_STR_YMDHMSS = "yyyyMMddHHmmssSSS";
MyDateFormat.DATE_FORMAT_STR_YMD = "yyyy-MM-dd";
MyDateFormat.DATE_FORMAT_STR_YMD_ = "yyyy/MM/dd";
MyDateFormat.DATE_FORMAT_STR_YMDHM = "yyyy-MM-dd HH:mm";
MyDateFormat.DATE_FORMAT_STR_MD = "MM-dd";
MyDateFormat.DATE_FORMAT_STR_MDHM = "MM-dd HH:mm";
MyDateFormat.DATE_FORMAT_STR = "yyyyMMddHHmm";
MyDateFormat.DATE_FORMAT_STRS = "yyyyMMddHHmmss";
MyDateFormat.DATE_FORMAT_STR_YM = "yyyy-MM";
MyDateFormat.DATE_FORMAT_STR_YMD_NOGAP = "yyyyMMdd";

class ChangeFilter {
    constructor(changes) {
        this.changes = changes;
    }
    notFirstAndEmpty(key) {
        const change = this.changes[key];
        if (isDef(change) && !change.isFirstChange()) {
            const value = change.currentValue;
            if (isDef(value)) {
                return of(value);
            }
        }
        return EMPTY;
    }
    notEmpty(key) {
        const change = this.changes[key];
        if (isDef(change)) {
            const value = change.currentValue;
            if (isDef(value)) {
                return of(value);
            }
        }
        return EMPTY;
    }
}

/*
 * Public API Surface of commonLib
 */

/**
 * Generated bundle index. Do not edit.
 */

export { AfterRender, BedsideConstants, ChangeFilter, Color, CommonLibModule, ModalDrag, MyDateFormat, MyFont, SwingConstants, TrustUrlPipe, after, base64Decode, base64Encode, before, cnToUnicode, dateTransformStr, formatBytes, formatTransform, getAge, getDate, getDecimalFormat, getIntAge, getNum45, isChina, isDef, isHasVal, isInteger, isItemInArr, isNOTDef, isNoVal, makeUUIDString, strLimit, strToUnicode, utf8Decode, utf8Encode, zeroSecAndMs };
//# sourceMappingURL=dxm-base-common-zhu.mjs.map

/**
 * Created by 刘云飞 on 2023/2/8
 * Copyright by 深医信息技术（深圳）有限公司
 */
export declare class BedsideConstants {
    static readonly PARAM_IBP_S: string;
    static readonly PARAM_IBP_D: string;
    static readonly PARAM_IBP_M: string;
    static readonly PARAM_NIBP_S: string;
    static readonly PARAM_NIBP_D: string;
    static readonly PARAM_NIBP_M: string;
    static readonly PARAM_RESP = "param_resp";
    static readonly PARAM_RESP_CTRL = "param_resp_ctrl";
    static readonly PARAM_RESP_FUZHU = "param_resp_fuzhu";
    static readonly PARAM_BLOOD_BGA_Y: string;
}

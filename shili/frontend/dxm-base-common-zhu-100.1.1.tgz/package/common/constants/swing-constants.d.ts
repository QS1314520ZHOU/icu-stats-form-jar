export declare class SwingConstants {
    static CENTER: number;
    /**
     * Box-orientation constant used to specify the top of a box.
     */
    static TOP: number;
    /**
     * Box-orientation constant used to specify the left side of a box.
     */
    static LEFT: number;
    /**
     * Box-orientation constant used to specify the bottom of a box.
     */
    static BOTTOM: number;
    /**
     * Box-orientation constant used to specify the right side of a box.
     */
    static RIGHT: number;
    /**
     * Compass-direction North (up).
     */
    static NORTH: number;
    /**
     * Compass-direction north-east (upper right).
     */
    static NORTH_EAST: number;
    /**
     * Compass-direction east (right).
     */
    static EAST: number;
    /**
     * Compass-direction south-east (lower right).
     */
    static SOUTH_EAST: number;
    /**
     * Compass-direction south (down).
     */
    static SOUTH: number;
    /**
     * Compass-direction south-west (lower left).
     */
    static SOUTH_WEST: number;
    /**
     * Compass-direction west (left).
     */
    static WEST: number;
    /**
     * Compass-direction north west (upper left).
     */
    static NORTH_WEST: number;
}

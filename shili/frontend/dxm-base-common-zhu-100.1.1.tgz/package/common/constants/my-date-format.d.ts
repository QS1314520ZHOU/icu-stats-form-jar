export declare class MyDateFormat {
    static DATE_FORMAT_STR_Y?: string;
    static DATE_FORMAT_STR_M?: string;
    static DATE_FORMAT_STR_D?: string;
    static DATE_FORMAT_STR_HM?: string;
    static DATE_FORMAT_STR_hh?: string;
    static DATE_FORMAT_STR_mm?: string;
    static DATE_FORMAT_STR_YMDHMS?: string;
    static DATE_FORMAT_STR_YMDHMS_?: string;
    static DATE_FORMAT_STR_YMDHMSsss?: string;
    static DATE_FORMAT_STR_YMDHMSS?: string;
    static DATE_FORMAT_STR_YMD?: string;
    static DATE_FORMAT_STR_YMD_?: string;
    static DATE_FORMAT_STR_YMDHM?: string;
    static DATE_FORMAT_STR_MD?: string;
    static DATE_FORMAT_STR_MDHM?: string;
    static DATE_FORMAT_STR?: string;
    static DATE_FORMAT_STRS?: string;
    static DATE_FORMAT_STR_YM?: string;
    static DATE_FORMAT_STR_YMD_NOGAP?: string;
}

export declare class Color {
    /**
     * The color white.  In the default sRGB space.
     */
    static readonly white: Color;
    static readonly WHITE: Color;
    /**
     * The color light gray.  In the default sRGB space.
     */
    static readonly lightGray: Color;
    static readonly LIGHT_GRAY: Color;
    /**
     * The color gray.  In the default sRGB space.
     */
    static readonly gray: Color;
    static readonly GRAY: Color;
    /**
     * The color dark gray.  In the default sRGB space.
     */
    static readonly darkGray: Color;
    static readonly DARK_GRAY: Color;
    /**
     * The color black.  In the default sRGB space.
     */
    static readonly black: Color;
    static readonly BLACK: Color;
    /**
     * The color red.  In the default sRGB space.
     */
    static readonly red: Color;
    static readonly RED: Color;
    /**
     * The color pink.  In the default sRGB space.
     */
    static readonly pink: Color;
    static readonly PINK: Color;
    /**
     * The color orange.  In the default sRGB space.
     */
    static readonly orange: Color;
    static readonly ORANGE: Color;
    /**
     * The color yellow.  In the default sRGB space.
     */
    static readonly yellow: Color;
    static readonly YELLOW: Color;
    /**
     * The color green.  In the default sRGB space.
     */
    static readonly green: Color;
    static readonly GREEN: Color;
    /**
     * The color magenta.  In the default sRGB space.
     */
    static readonly magenta: Color;
    static readonly MAGENTA: Color;
    /**
     * The color cyan.  In the default sRGB space.
     */
    static readonly cyan: Color;
    static readonly CYAN: Color;
    /**
     * The color blue.  In the default sRGB space.
     */
    static readonly blue: Color;
    static readonly BLUE: Color;
    /**
     * The color Navy Blue.  In the default sRGB space.
     */
    static readonly navyblue: Color;
    static readonly NAVYBLUE: Color;
    readonly r: number;
    readonly g: number;
    readonly b: number;
    readonly a: number;
    readonly alpha: number;
    /**
     * @param r Red component.
     * @param g Green component.
     * @param b Blue component.
     * @param a Alpha (opacity) component. 透明度，0到255，千万别写1（很透明的了），也别写100
     */
    constructor(r: number, g: number, b: number, a?: number);
    /**
     * 字符串转成颜色
     * 颜色字符串支持十六进制和 RGB(RGBA)格式
     * @param str: 颜色字符串
     */
    static fromString(str: string): Color;
    /**
     * 将十六进制的颜色字符串转换成颜色
     * @param str: 颜色字符串。eg: #FF00FF
     */
    static fromHexString(str: string): Color;
    /**
     * 将 RGB 或 RGBA 格式的颜色字符串转换成颜色
     * @param str: 颜色字符串。eg: rgba(255, 255, 255, 255)、rgb(255, 0, 255)
     */
    static fromRgbaString(str: string): Color;
    toString(): string;
    /**
     * 将十进制数转成十六进制，不足两位前面补0
     * @param num
     */
    toHexString(num: number): string;
    toUpCaseString(): string;
    toRgbaString(): string;
    clone(): Color;
}

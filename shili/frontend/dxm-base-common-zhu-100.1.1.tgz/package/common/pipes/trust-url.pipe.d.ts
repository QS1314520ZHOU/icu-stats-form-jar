import { PipeTransform } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export declare class TrustUrlPipe implements PipeTransform {
    private sanitizer;
    constructor(sanitizer: DomSanitizer);
    transform(base64: string): SafeResourceUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<TrustUrlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<TrustUrlPipe, "trustUrl">;
}

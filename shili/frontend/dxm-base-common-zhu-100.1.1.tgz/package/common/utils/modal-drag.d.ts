import { Subject } from "rxjs/internal/Subject";
export declare class ModalDrag {
    static destroyMap: Map<string, Subject<void>>;
    static isStart: boolean;
    static observeModalDrag(): void;
    private static modalBindEventAndListen;
}

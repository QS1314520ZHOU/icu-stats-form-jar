import { Observable } from "rxjs";
export declare class AfterRender {
    /**
     * @param el  要监听的DOM元素
     * @param fn  DOM改变后要调用的函数
     */
    static finishedFn(el: HTMLElement, fn: () => void): void;
    static finishedObs(el: HTMLElement): Observable<any>;
}

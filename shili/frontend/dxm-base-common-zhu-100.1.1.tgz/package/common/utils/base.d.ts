/**
 * 返回格式化数字, 数字为整数返回不带0, 不为整数则会补位小数0
 * @param val 原值
 * @param floatCount 格式化指定小数位
 */
export declare function getDecimalFormat(val: number, floatCount: number): string;
/**
 * 取得四舍五入后的浮点数
 * @param val 原值
 * @param floatCount 四舍五入小数位
 */
export declare function getNum45(val: number, floatCount: number): number;
/**
 * 判断是否整数
 * @param val 待判断值
 */
export declare function isInteger(val: number): boolean;
export declare function makeUUIDString(): string;
export declare function isChina(str: string): boolean;
export declare function formatTransform(str: string): string;
export declare function isDef(val: any): boolean;
export declare function isNOTDef(val: any): boolean;
export declare function isHasVal(val: any): boolean;
export declare function isNoVal(val: any): boolean;
/**
 * 裁切字符串
 * @param str 输入原始字符串
 * @param limit 裁切后的长度
 */
export declare function strLimit(str: string, limit: number): string;
/**
 * 公共方法
 * 判断字符串是否在数组中出现
 * @param str 字符串
 * @param arr 数组
 */
export declare function isItemInArr(str: any, arr: Array<any>): boolean;
/**
 * 字符串转unicode (正则表达查询需要把中文转unicode)
 * @param str 待转码字符串
 */
export declare function strToUnicode(str: string): string;
/**
 * 单个中文字符转unicode
 * @param cn 单个中文字符
 */
export declare function cnToUnicode(cn: string): string;
/**
 * Base64解码--（xiao)
 */
export declare function base64Decode(input: string): string;
export declare function base64Encode(input: string): string;
export declare function utf8Encode(str: string): string;
/**
 * UTF-8解码--（xiao)
 */
export declare function utf8Decode(utftext: string): string;
export declare function formatBytes(size: number, b?: number): string;
export declare function dateTransformStr(date: Date, format: string): string;

/**
 * 日期工具方法集合
 * Created by Jeremy 2023-02-08 16:20:58
 * Copyright by 深医信息技术（深圳）有限公司
 *
 */
/**
 * 判断d1是否在d2之前
 * @param d1 日期1
 * @param d2 日期2
 */
export declare function before(d1: Date | number, d2: Date | number, equals?: boolean): boolean;
/**
 * 判断d1是否在d2之后
 * @param d1 日期1
 * @param d2 日期2
 */
export declare function after(d1: Date | number, d2: Date | number, equals?: boolean): boolean;
export declare function getDate(d: Date | number): Date;
export declare function zeroSecAndMs(date: Date | number): Date;

/**
 * 按照当前日期获取岁数
 * @param dob    出生日期
 */
export declare function getAge(dob: number): number;
/**
 * 根据传入的时间获取岁数
 * @param dob    出生日期
 * @param inRoomTime  入手术室时间
 */
export declare function getIntAge(dob: number, inRoomTime: number): number;

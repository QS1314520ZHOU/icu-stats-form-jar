/**
 * Created by 叶建、邱三 on 2023/1/29
 * Copyright by 深医信息技术（深圳）有限公司
 * 适用于 Array 和 【】 两种写法
 */
declare global {
    export interface Array<T> {
        addToFront(o: T): boolean;
        add(one: T): boolean;
        addAt(index: number, o: T): boolean;
        remove(o: T): T[] | undefined;
        removeAt(index: number): T[] | undefined;
        removeSome(o: T[]): T[];
        removeSomeAt(indexs: number[]): T[];
        clear(): T[] | undefined;
        has(one: T): boolean;
    }
}
export {};

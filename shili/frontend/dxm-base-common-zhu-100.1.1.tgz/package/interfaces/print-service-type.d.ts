/**
 * 翻转属性（单面打印 | 短边翻转 | 长边翻转）
 */
export declare type DuplexMode = 'simplex' | 'shortEdge' | 'longEdge';
/**
 * 纸张类型
 */
export declare type PageSize = 'A4' | 'A2' | 'A3' | 'A5' | 'A6';
/**
 * Java打印程序参数
 */
export interface JavaPrintOpt {
    /**
     * 指定打印机名字
     */
    printerName?: string;
    /**
     * 横纵向打印
     */
    orientation?: TypeOrientation;
    /**
     * 是否彩色打印，默认false
     */
    color?: boolean;
    /**
     * 打印单双页模式
     */
    duplexMode?: DuplexMode;
    /**
     * 纸张类型
     */
    pageSize?: PageSize;
    /**
     * 打印份数
     */
    copies?: number;
    /**
     * 正面上偏移量
     */
    top?: number;
    /**
     * 反面上偏移量
     */
    top2?: number;
    /**
     * 正面左偏移量
     */
    left?: number;
    /**
     * 反面左偏移量
     */
    left2?: number;
    /**
     * 要打印的指定页，逗号分割（比如：“1,3,5,6”就是打印1、3、5、6页，不传则打印全部）
     */
    pages?: string;
    /**
     * 缩放
     */
    scale?: number;
    /**
     * 是否采用打印机默认配置
     * 1: 使用打印机默认配置，除了那5个属性有效，其他属性设置失效
     * 0：使用程序设置的属性
     */
    showPrtDlg?: 0 | 1;
}
/**
 * PDF打印传参(Java程序)
 */
export interface PdfPrintParamsJava {
    file?: string | ArrayBuffer;
    option?: JavaPrintOpt;
}
/**
 * 调用exe的传参
 */
export interface RunExeParam {
    /**
     * exe调用的路径：如："C:/Program Files (x86)/NetSarang/Xshell 6/Xshell.exe"
     */
    filePath: string;
    /**
     * 调用路径后面要添加的参数，如传入"aaa"，则会拼接成 "C:/Program Files (x86)/NetSarang/Xshell 6/Xshell.exe aaa"
     */
    param: string;
}
/**
 * 纵向/横向
 */
export declare type TypeOrientation = 'portrait' | 'landscape';

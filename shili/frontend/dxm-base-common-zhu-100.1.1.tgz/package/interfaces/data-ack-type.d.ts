export interface DataAck<T> {
    /**
     * 告诉后台请求数据的方式，比如是请求数据还是请求心跳包
     */
    backendChannel: string;
    /**
     * 大的请求方法类别：比如执行用药
     */
    frontendChannel: string;
    /**
     * 小的细分请求方法：比如执行用药下面的请求用药方式
     */
    frontendChannelMethod: string;
    /**
     * 200默认都是成功的，501表示数据热更新异常，如：多个客户端操作的情况下
     */
    code: number;
    /**
     * 后端传过来的数据
     */
    data: T;
    /**
     * 错误信息
     */
    error?: string;
    /**
     * 消息唯一id
     */
    msgId?: number;
}
export interface DataParam {
    /**
     * 告诉后台请求数据的方式，比如是请求数据还是请求心跳包
     */
    backendChannel?: string;
    /**
     * 大的请求方法类别：比如执行用药
     */
    frontendChannel?: string;
    /**
     * 小的细分请求方法：比如执行用药下面的请求用药方式
     */
    frontendChannelMethod?: string;
    /**
     * 数据
     */
    data?: any;
    /**
     * 消息唯一id
     */
    msgId?: number;
}
/**
 * 前端抛出的异常的数据类型
 */
export interface DataError<T> {
    /**
     * 501表示数据热更新异常，如：多个客户端操作的情况下
     */
    code: number;
    /**
     * 错误信息
     */
    error?: string;
    /**
     * 后端传过来的数据，即数据库最新数据
     */
    data?: T;
}
